@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title DemainSite - Installer tache mensuelle Geo

echo ============================================================
echo  DEMAINSITE ECOSYSTEME - TACHE MENSUELLE GEO
echo ============================================================
echo.

where pwsh >nul 2>nul
if %errorlevel%==0 (
    pwsh -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\INSTALL-TACHE-MENSUELLE.ps1"
) else (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\INSTALL-TACHE-MENSUELLE.ps1"
)

echo.
pause
