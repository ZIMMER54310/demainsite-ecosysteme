@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title DemainSite - Communes France completes

echo ============================================================
echo  DEMAINSITE ECOSYSTEME - COMMUNES DE FRANCE COMPLETES V2.1
echo ============================================================
echo.
echo Ce lanceur va :
echo  - chercher ou telecharger le CSV geographique complet,
echo  - completer Regions, Departements, Villes, CodesPostaux,
echo  - completer CodesPostauxVilles,
echo  - ne rien supprimer.
echo.
set /p CONFIRM=Ecris OUI pour lancer l'installation complete : 
if /I not "%CONFIRM%"=="OUI" (
    echo Annule.
    pause
    exit /b 0
)

where pwsh >nul 2>nul
if %errorlevel%==0 (
    pwsh -NoProfile -ExecutionPolicy Bypass -File "%~dp0RUN-INSTALL-COMMUNES-FRANCE-COMPLETES.ps1" -Mode Update
) else (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0RUN-INSTALL-COMMUNES-FRANCE-COMPLETES.ps1" -Mode Update
)

echo.
echo Termine. Tu peux fermer cette fenetre apres verification.
pause
