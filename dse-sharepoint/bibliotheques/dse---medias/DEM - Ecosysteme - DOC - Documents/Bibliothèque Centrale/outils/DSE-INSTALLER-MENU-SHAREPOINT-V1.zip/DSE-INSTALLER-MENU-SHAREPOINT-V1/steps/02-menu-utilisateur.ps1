﻿param([string]$Root)
. "$PSScriptRoot\_common.ps1"
Connect-DSESharePoint

$web = Get-PnPWeb
$siteRel = $web.ServerRelativeUrl
if ($siteRel -eq "/") { $siteRel = "" }
$homeUrl = "$siteRel/SitePages/$script:HomePageName"

# URLs utiles
$uRelations = Get-DSEListUrl "Relations"
$uClients = Get-DSEListUrl "Clients"
$uSites = Get-DSEListUrl "Sites"
$uProjets = Get-DSEListUrl "Projets"
$uMedias = Get-DSEListUrl "Medias"
$uPages = Get-DSEListUrl "Pages"
$uDomaines = Get-DSEListUrl "Domaines"
$uUtilisateurs = Get-DSEListUrl "Utilisateurs"
$uCatalogueListes = Get-DSEListUrl "CatalogueListes"
$uCatalogueInstallateurs = Get-DSEListUrl "CatalogueInstallateurs"
$uJournalActions = Get-DSEListUrl "JournalActions"
$uJournalErreurs = Get-DSEListUrl "JournalErreurs"
$uProcedures = Get-DSEListUrl "Procedures"

# Titres connus a retirer pour eviter le bazar. Ne supprime aucune liste, uniquement les liens du menu.
$titlesToRemove = @(
    "Accueil DemainSite",
    "--- TRAVAIL PRINCIPAL ---",
    "Relations",
    "Clients",
    "Sites",
    "Projets",
    "Medias",
    "Médias",
    "Pages",
    "Domaines",
    "Utilisateurs",
    "--- ADMINISTRATION ---",
    "Catalogue listes",
    "CatalogueListes",
    "Catalogue installateurs",
    "CatalogueInstallateurs",
    "Journal actions",
    "JournalActions",
    "Journal erreurs",
    "JournalErreurs",
    "Procedures",
    "Procédures",
    "--- REFERENTIELS ---",
    "Référentiels",
    "Referentiels",
    "Civilites",
    "Statuts",
    "TypesRelations",
    "TypesSites",
    "TypesDomaines",
    "TypesProjets",
    "TypesMedia",
    "CategoriesMedia",
    "CategoriesPages",
    "Licences",
    "RolesUtilisateurs",
    "Pays",
    "Langues"
)

foreach ($t in $titlesToRemove) { Remove-DSEQuickLaunchTitle -Title $t }

# Menu utilisateur simple
Add-DSEQuickLaunchLink -Title "Accueil DemainSite" -Url $homeUrl
Add-DSEQuickLaunchLink -Title "--- TRAVAIL PRINCIPAL ---" -Url $homeUrl
Add-DSEQuickLaunchLink -Title "Relations" -Url $uRelations
Add-DSEQuickLaunchLink -Title "Clients" -Url $uClients
Add-DSEQuickLaunchLink -Title "Sites" -Url $uSites
Add-DSEQuickLaunchLink -Title "Projets" -Url $uProjets
Add-DSEQuickLaunchLink -Title "Medias" -Url $uMedias
Add-DSEQuickLaunchLink -Title "Pages" -Url $uPages
Add-DSEQuickLaunchLink -Title "Domaines" -Url $uDomaines
Add-DSEQuickLaunchLink -Title "Utilisateurs" -Url $uUtilisateurs
Add-DSEQuickLaunchLink -Title "--- ADMINISTRATION ---" -Url $homeUrl
Add-DSEQuickLaunchLink -Title "Catalogue listes" -Url $uCatalogueListes
Add-DSEQuickLaunchLink -Title "Installateurs" -Url $uCatalogueInstallateurs
Add-DSEQuickLaunchLink -Title "Journal actions" -Url $uJournalActions
Add-DSEQuickLaunchLink -Title "Journal erreurs" -Url $uJournalErreurs
Add-DSEQuickLaunchLink -Title "Procedures" -Url $uProcedures
Add-DSEQuickLaunchLink -Title "--- REFERENTIELS ---" -Url $homeUrl
Add-DSEQuickLaunchLink -Title "Referentiels" -Url $uCatalogueListes

Add-DSEJournalAction -Action "Modification menu SharePoint" -Objet "QuickLaunch" -Resultat "OK" -Message "Menu simplifie : Travail principal, Administration, Referentiels. Les anciennes listes techniques sont retirees du menu mais pas supprimees."
