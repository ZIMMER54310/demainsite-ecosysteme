﻿param([string]$Root)
. "$PSScriptRoot\_common.ps1"
Connect-DSESharePoint
$nodes = Get-PnPNavigationNode -Location QuickLaunch -ErrorAction SilentlyContinue
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " CONTROLE FINAL MENU SHAREPOINT" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
foreach ($n in $nodes) { Write-Host (" - " + $n.Title) -ForegroundColor Green }
Write-Host "============================================================" -ForegroundColor Cyan
Add-DSEJournalAction -Action "Controle final menu SharePoint" -Objet "QuickLaunch" -Resultat "OK" -Message "Controle final du menu execute."
