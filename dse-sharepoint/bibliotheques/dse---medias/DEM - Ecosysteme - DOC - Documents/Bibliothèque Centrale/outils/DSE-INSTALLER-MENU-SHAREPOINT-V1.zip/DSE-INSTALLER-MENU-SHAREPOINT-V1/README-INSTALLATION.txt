﻿DSE-INSTALLER-MENU-SHAREPOINT-V1

But : modifier uniquement le menu gauche SharePoint pour le rendre plus logique pour un utilisateur.

Le pack :
- retire uniquement les liens de menu connus qui encombrent le menu,
- ne supprime aucune liste SharePoint,
- ajoute un menu simple : Accueil DemainSite, Travail principal, Administration, Referentiels,
- journalise dans JournalActions si disponible.

Utilisation :
1. Placer le dossier dans OUTILS / INSTALLATEURS.
2. Double-cliquer RUN-DSE.bat.
3. Actualiser SharePoint.

Aucune donnée supprimée.
Aucune modification WordPress.
