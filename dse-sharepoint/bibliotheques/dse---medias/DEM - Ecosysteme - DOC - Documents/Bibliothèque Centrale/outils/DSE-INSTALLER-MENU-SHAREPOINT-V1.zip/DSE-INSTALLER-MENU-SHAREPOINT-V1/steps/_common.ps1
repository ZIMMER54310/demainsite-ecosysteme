﻿$script:SpUrl = "https://blogssite.sharepoint.com/sites/Bibliotheque"
$script:ClientId = "5d607413-77c5-47b2-975a-eaca6827921c"
$script:Tenant = "demainsite.com"
$script:HomePageName = "Accueil-DemainSite-Ecosysteme.aspx"

function Connect-DSESharePoint {
    try {
        $web = Get-PnPWeb -ErrorAction Stop
        Write-Host "Connexion SharePoint active : $($web.Url)" -ForegroundColor Green
    } catch {
        Write-Host "Connexion SharePoint absente. Connexion DeviceLogin..." -ForegroundColor Yellow
        Connect-PnPOnline -Url $script:SpUrl -ClientId $script:ClientId -Tenant $script:Tenant -DeviceLogin
        $web = Get-PnPWeb -ErrorAction Stop
        Write-Host "Connexion SharePoint OK : $($web.Url)" -ForegroundColor Green
    }
}

function Get-DSEListUrl {
    param([string]$ListName)
    $list = Get-PnPList -Identity $ListName -ErrorAction SilentlyContinue
    if ($null -eq $list) { return "#" }
    return $list.RootFolder.ServerRelativeUrl
}

function Add-DSEJournalAction {
    param([string]$Action,[string]$Objet,[string]$Resultat,[string]$Message)
    try {
        $list = Get-PnPList -Identity "JournalActions" -ErrorAction SilentlyContinue
        if ($null -eq $list) { return }
        $items = Get-PnPListItem -List "JournalActions" -PageSize 2000 -Fields "IDJournal" -ErrorAction SilentlyContinue
        $max = 0
        foreach ($item in $items) {
            $v = "$($item['IDJournal'])"
            if ($v -match "^JRN-([0-9]+)$") { $n = [int]$matches[1]; if ($n -gt $max) { $max = $n } }
        }
        $id = ("JRN-{0:D6}" -f ($max + 1))
        Add-PnPListItem -List "JournalActions" -Values @{
            "Title"=$Action; "IDJournal"=$id; "DateAction"=Get-Date; "Source"="PowerShell"; "Objet"=$Objet; "Resultat"=$Resultat; "Message"=$Message; "Utilisateur"=$env:USERNAME
        } | Out-Null
    } catch { Write-Host "Journal non ecrit : $($_.Exception.Message)" -ForegroundColor Yellow }
}

function Remove-DSEQuickLaunchTitle {
    param([string]$Title)
    $nodes = Get-PnPNavigationNode -Location QuickLaunch -ErrorAction SilentlyContinue | Where-Object { $_.Title -eq $Title }
    foreach ($node in $nodes) {
        try {
            Remove-PnPNavigationNode -Identity $node.Id -Force | Out-Null
            Write-Host "Menu retire : $Title" -ForegroundColor Yellow
        } catch {
            Write-Host "Menu non retire : $Title / $($_.Exception.Message)" -ForegroundColor Yellow
        }
    }
}

function Add-DSEQuickLaunchLink {
    param([string]$Title,[string]$Url)
    try {
        Add-PnPNavigationNode -Title $Title -Url $Url -Location QuickLaunch | Out-Null
        Write-Host "Menu ajoute : $Title" -ForegroundColor Green
    } catch {
        Write-Host "Menu non ajoute : $Title / $($_.Exception.Message)" -ForegroundColor Yellow
    }
}
