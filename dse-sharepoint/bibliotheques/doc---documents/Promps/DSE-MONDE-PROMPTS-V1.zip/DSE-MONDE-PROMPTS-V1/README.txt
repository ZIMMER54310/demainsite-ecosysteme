DSE MONDE PROMPTS V1
Validation Pascal : CULTURE + DRAPEAU PREMIER PLAN
Usage futur DemainSite / SharePoint
