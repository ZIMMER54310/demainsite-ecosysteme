﻿$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$TaskName = "DSE-Synchro-Globale-12h"
$Script = Join-Path $Root "install.ps1"
$Pwsh = (Get-Command pwsh -ErrorAction SilentlyContinue).Source
if (-not $Pwsh) { $Pwsh = (Get-Command powershell -ErrorAction Stop).Source }
$Action = New-ScheduledTaskAction -Execute $Pwsh -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$Script`""
$Trigger1 = New-ScheduledTaskTrigger -Daily -At 7:00
$Trigger2 = New-ScheduledTaskTrigger -Daily -At 19:00
$Settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -StartWhenAvailable
Register-ScheduledTask -TaskName $TaskName -Action $Action -Trigger @($Trigger1,$Trigger2) -Settings $Settings -Description "DemainSite Ecosysteme - Synchronisation globale toutes les 12h" -Force | Out-Null
Write-Host "Tache planifiee creee ou mise a jour : $TaskName" -ForegroundColor Green
Write-Host "Elle lance : $Script" -ForegroundColor Cyan
