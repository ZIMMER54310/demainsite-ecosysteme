﻿@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo DEMAINSITE ECOSYSTEME - PLANIFICATION SYNCHRO 12H
echo ============================================================
echo.
pwsh -NoProfile -ExecutionPolicy Bypass -File "%~dp0planifier-12h.ps1"
echo.
pause
