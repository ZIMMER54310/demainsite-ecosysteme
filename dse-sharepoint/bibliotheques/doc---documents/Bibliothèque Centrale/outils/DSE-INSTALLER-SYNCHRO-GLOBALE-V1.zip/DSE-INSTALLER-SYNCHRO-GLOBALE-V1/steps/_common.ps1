﻿$script:SpUrl = "https://blogssite.sharepoint.com/sites/Bibliotheque"
$script:ClientId = "5d607413-77c5-47b2-975a-eaca6827921c"
$script:Tenant = "demainsite.com"
function Connect-DSESharePoint {
    try {
        $web = Get-PnPWeb -ErrorAction Stop
        Write-Host "Connexion SharePoint active : $($web.Url)" -ForegroundColor Green
    } catch {
        Write-Host "Connexion SharePoint absente. Connexion DeviceLogin..." -ForegroundColor Yellow
        Connect-PnPOnline -Url $script:SpUrl -ClientId $script:ClientId -Tenant $script:Tenant -DeviceLogin
        $web = Get-PnPWeb -ErrorAction Stop
        Write-Host "Connexion SharePoint OK : $($web.Url)" -ForegroundColor Green
    }
}
function Ensure-DSEList { param([string]$Title)
    $list = Get-PnPList -Identity $Title -ErrorAction SilentlyContinue
    if ($null -eq $list) { New-PnPList -Title $Title -Template GenericList -OnQuickLaunch | Out-Null; Write-Host "Liste creee : $Title" -ForegroundColor Green }
    else { Write-Host "Liste deja presente : $Title" -ForegroundColor DarkGreen }
}
function Ensure-DSEField { param([string]$ListName,[string]$DisplayName,[string]$InternalName,[string]$Type)
    $field = Get-PnPField -List $ListName -Identity $InternalName -ErrorAction SilentlyContinue
    if ($null -eq $field) { Add-PnPField -List $ListName -DisplayName $DisplayName -InternalName $InternalName -Type $Type | Out-Null; Write-Host "Colonne ajoutee : $ListName / $DisplayName" -ForegroundColor Green }
    else { Write-Host "Colonne deja presente : $ListName / $DisplayName" -ForegroundColor DarkGreen }
}
function New-DSEId { param([string]$ListName,[string]$FieldName,[string]$Prefix)
    $items = Get-PnPListItem -List $ListName -PageSize 2000 -Fields $FieldName -ErrorAction SilentlyContinue
    $max = 0
    foreach ($item in $items) { $v = "$($item[$FieldName])"; if ($v -match "^$Prefix-([0-9]+)$") { $n = [int]$matches[1]; if ($n -gt $max) { $max = $n } } }
    return ("{0}-{1:D6}" -f $Prefix, ($max + 1))
}
function Add-DSEJournalAction { param([string]$Action,[string]$Objet,[string]$Resultat,[string]$Message)
    try {
        $list = Get-PnPList -Identity "JournalActions" -ErrorAction SilentlyContinue
        if ($null -eq $list) { return }
        $id = New-DSEId -ListName "JournalActions" -FieldName "IDJournal" -Prefix "JRN"
        Add-PnPListItem -List "JournalActions" -Values @{ "Title"=$Action; "IDJournal"=$id; "DateAction"=Get-Date; "Source"="PowerShell"; "Objet"=$Objet; "Resultat"=$Resultat; "Message"=$Message; "Utilisateur"=$env:USERNAME } | Out-Null
    } catch { Write-Host "Journal non ecrit : $($_.Exception.Message)" -ForegroundColor Yellow }
}
