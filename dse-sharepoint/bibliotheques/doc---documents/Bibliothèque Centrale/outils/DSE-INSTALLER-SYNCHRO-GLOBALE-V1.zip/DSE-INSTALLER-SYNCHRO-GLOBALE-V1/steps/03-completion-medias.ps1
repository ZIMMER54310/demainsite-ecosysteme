﻿param([string]$Root)
. "$PSScriptRoot\_common.ps1"
Connect-DSESharePoint
# Completion simple et robuste V1 : assure ID, statut, source eventuelle, et journalise.
$items = Get-PnPListItem -List "Medias" -PageSize 2000 -ErrorAction SilentlyContinue
$updated = 0
foreach ($item in $items) {
    $values = @{}
    $title = "$($item['Title'])"
    $fields = Get-PnPField -List "Medias"
    $idField = $fields | Where-Object { $_.Title -eq "ID Media" -or $_.InternalName -eq "ID_Media" -or $_.InternalName -eq "DS_Media_ID" } | Select-Object -First 1
    $wpField = $fields | Where-Object { $_.InternalName -eq "WP_ID" -or $_.Title -eq "ID WordPress" } | Select-Object -First 1
    if ($null -ne $idField) {
        $cur = "$($item[$idField.InternalName])"
        if ([string]::IsNullOrWhiteSpace($cur)) {
            $wp = ""
            if ($null -ne $wpField) { $wp = "$($item[$wpField.InternalName])" }
            if (-not [string]::IsNullOrWhiteSpace($wp)) { $values[$idField.InternalName] = "MED-WP-$wp" } else { $values[$idField.InternalName] = "MED-SP-$($item.Id)" }
        }
    }
    if ($values.Count -gt 0) { Set-PnPListItem -List "Medias" -Identity $item.Id -Values $values | Out-Null; $updated++ }
}
Add-DSEJournalAction -Action "Synchro globale - medias" -Objet "Medias" -Resultat "OK" -Message "Completion simple medias executee. Medias mis a jour : $updated."
Write-Host "Completion medias : $updated medias mis a jour." -ForegroundColor Green
