﻿param([string]$Root)
. "$PSScriptRoot\_common.ps1"
Connect-DSESharePoint
Ensure-DSEList -Title "CentreSynchronisation"
Ensure-DSEField -ListName "CentreSynchronisation" -DisplayName "ID Synchro" -InternalName "IDSynchro" -Type Text
Ensure-DSEField -ListName "CentreSynchronisation" -DisplayName "Type Synchro" -InternalName "TypeSynchro" -Type Text
Ensure-DSEField -ListName "CentreSynchronisation" -DisplayName "Statut" -InternalName "Statut" -Type Text
Ensure-DSEField -ListName "CentreSynchronisation" -DisplayName "Derniere execution" -InternalName "DerniereExecution" -Type DateTime
Ensure-DSEField -ListName "CentreSynchronisation" -DisplayName "Frequence" -InternalName "Frequence" -Type Text
Ensure-DSEField -ListName "CentreSynchronisation" -DisplayName "Message" -InternalName "Message" -Type Note
$existing = Get-PnPListItem -List "CentreSynchronisation" -PageSize 2000 -Fields "Title" -ErrorAction SilentlyContinue | Where-Object { $_["Title"] -eq "Synchronisation globale" } | Select-Object -First 1
$values = @{ "Title"="Synchronisation globale"; "IDSynchro"="SYNC-000001"; "TypeSynchro"="Completion automatique"; "Statut"="Actif"; "DerniereExecution"=Get-Date; "Frequence"="Manuel ou 12h"; "Message"="Lance les completions automatiques DemainSite : medias, catalogue, journaux. Version V1 locale via RUN-DSE." }
if ($null -eq $existing) { Add-PnPListItem -List "CentreSynchronisation" -Values $values | Out-Null; Write-Host "CentreSynchronisation initialise." -ForegroundColor Green }
else { Set-PnPListItem -List "CentreSynchronisation" -Identity $existing.Id -Values $values | Out-Null; Write-Host "CentreSynchronisation mis a jour." -ForegroundColor Yellow }
Add-DSEJournalAction -Action "Initialisation CentreSynchronisation" -Objet "CentreSynchronisation" -Resultat "OK" -Message "Centre de synchronisation cree ou mis a jour."
