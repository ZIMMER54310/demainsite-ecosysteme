﻿param([string]$Root)
. "$PSScriptRoot\_common.ps1"
Connect-DSESharePoint
# Refresh simple du nombre d'elements dans CatalogueListes si disponible.
$cat = Get-PnPList -Identity "CatalogueListes" -ErrorAction SilentlyContinue
if ($null -eq $cat) { Write-Host "CatalogueListes absent, refresh ignore." -ForegroundColor Yellow; return }
$catalogItems = Get-PnPListItem -List "CatalogueListes" -PageSize 2000 -Fields "Title","NombreElements" -ErrorAction SilentlyContinue
$updated = 0
foreach ($ci in $catalogItems) {
    $name = "$($ci['Title'])"
    $list = Get-PnPList -Identity $name -ErrorAction SilentlyContinue
    if ($null -ne $list) {
        try { Set-PnPListItem -List "CatalogueListes" -Identity $ci.Id -Values @{ "NombreElements"=[int]$list.ItemCount; "DateScan"=Get-Date } | Out-Null; $updated++ } catch {}
    }
}
Add-DSEJournalAction -Action "Synchro globale - CatalogueListes" -Objet "CatalogueListes" -Resultat "OK" -Message "NombreElements rafraichi sur $updated lignes."
Write-Host "CatalogueListes rafraichi : $updated lignes." -ForegroundColor Green
