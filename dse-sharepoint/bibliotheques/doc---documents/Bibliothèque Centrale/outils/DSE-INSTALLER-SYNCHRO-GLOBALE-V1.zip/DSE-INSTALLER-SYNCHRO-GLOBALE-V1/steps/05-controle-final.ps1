﻿param([string]$Root)
. "$PSScriptRoot\_common.ps1"
Connect-DSESharePoint
$cs = (Get-PnPListItem -List "CentreSynchronisation" -PageSize 2000 -ErrorAction SilentlyContinue).Count
$ja = (Get-PnPListItem -List "JournalActions" -PageSize 2000 -ErrorAction SilentlyContinue).Count
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " CONTROLE FINAL SYNCHRO GLOBALE" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "CentreSynchronisation : $cs element(s)" -ForegroundColor Green
Write-Host "JournalActions        : $ja element(s)" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Cyan
Add-DSEJournalAction -Action "Controle final synchro globale" -Objet "Synchro globale" -Resultat "OK" -Message "Controle final execute."
