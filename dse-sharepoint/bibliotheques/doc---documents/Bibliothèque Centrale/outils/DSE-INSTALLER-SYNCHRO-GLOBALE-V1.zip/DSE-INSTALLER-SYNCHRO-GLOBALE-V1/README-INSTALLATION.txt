﻿DSE-INSTALLER-SYNCHRO-GLOBALE-V1

But : mettre en place un centre de synchronisation globale DemainSite.

V1 fait :
- cree CentreSynchronisation,
- lance une completion simple des Medias,
- rafraichit NombreElements dans CatalogueListes,
- journalise dans JournalActions,
- peut etre lance manuellement via RUN-DSE-SYNCHRO.bat,
- peut etre planifie localement 2 fois par jour via INSTALLER-TACHE-12H.bat.

Important :
- Un vrai bouton SharePoint cloud ou une execution toutes les 12h sans PC allume necessite Power Automate ou Azure Automation.
- Cette V1 fonctionne en local via PowerShell et SharePoint.

Mode manuel : double-cliquer RUN-DSE-SYNCHRO.bat.
Mode 12h local : double-cliquer INSTALLER-TACHE-12H.bat.
