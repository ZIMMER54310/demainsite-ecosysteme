﻿DSE-INSTALLER-GEOGRAPHIE-FRANCE-V1.1

Correctif de V1 :
- Corrige l'erreur ISO2 sur la liste Pays.
- Utilise CodeISO2 et StatutGeo pour ne pas entrer en conflit avec une ancienne structure Pays.
- Le script n'ecrit plus dans une colonne absente.

Utilisation :
1. Decompresser dans OUTILS / INSTALLATEURS / DSE-INSTALLER-GEOGRAPHIE-FRANCE-V1-1.
2. Lancer RUN-DSE-GEOGRAPHIE.bat.
3. Le CSV deja telecharge peut etre reutilise, sinon le script le telecharge.
4. L'import reprend sans supprimer ce qui existe deja.
