﻿param([string]$Root)
. "$PSScriptRoot\_common.ps1"
Connect-DSESharePoint
$dataDir = Join-Path $Root "data"
if (-not (Test-Path $dataDir)) { New-Item -ItemType Directory -Force -Path $dataDir | Out-Null }
$csvPath = Join-Path $dataDir "communes-departement-region.csv"
if (Test-Path $csvPath) { Write-Host "CSV deja present : $csvPath" -ForegroundColor Yellow; return }
$apiUrl = "https://www.data.gouv.fr/api/1/datasets/communes-de-france-base-des-codes-postaux/"
$dataset = Invoke-RestMethod -Uri $apiUrl -Method Get -ErrorAction Stop
$res = $dataset.resources | Where-Object { $_.format -eq "csv" -and ($_.title -like "*communes-departement-region*" -or $_.title -like "*20230823*") } | Select-Object -First 1
if ($null -eq $res) { $res = $dataset.resources | Where-Object { $_.format -eq "csv" } | Sort-Object filesize -Descending | Select-Object -First 1 }
if ($null -eq $res) { throw "Aucune ressource CSV trouvee sur data.gouv." }
Invoke-WebRequest -Uri $res.url -OutFile $csvPath -ErrorAction Stop
Write-Host "CSV telecharge : $csvPath" -ForegroundColor Green
Add-DSEJournalAction -Action "Telechargement source geographie V1.1" -Objet "CSV data.gouv" -Resultat "OK" -Message "Source telechargee : $($res.title)"
