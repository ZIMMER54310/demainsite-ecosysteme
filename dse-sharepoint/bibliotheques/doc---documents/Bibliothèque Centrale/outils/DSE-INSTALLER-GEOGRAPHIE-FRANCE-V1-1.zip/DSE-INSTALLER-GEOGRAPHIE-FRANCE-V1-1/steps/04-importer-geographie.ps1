﻿param([string]$Root)
. "$PSScriptRoot\_common.ps1"
Connect-DSESharePoint
$csvPath = Join-Path $Root "data\communes-departement-region.csv"
if (-not (Test-Path $csvPath)) { throw "CSV source absent : $csvPath" }
Write-Host "Lecture CSV : $csvPath" -ForegroundColor Cyan
$rows = Import-Csv -Path $csvPath
Write-Host "Lignes source : $($rows.Count)" -ForegroundColor Cyan

# France : ne jamais écrire dans une colonne absente. Utilise les vrais noms internes trouvés.
$paysFields = @{}
$paysFields.IDPays = Get-DSEFieldInternalName -ListName "Pays" -Names @("IDPays","ID Pays")
$paysFields.CodePays = Get-DSEFieldInternalName -ListName "Pays" -Names @("CodePays","Code Pays")
$paysFields.CodeISO2 = Get-DSEFieldInternalName -ListName "Pays" -Names @("CodeISO2","ISO2","Code ISO2")
$paysFields.StatutGeo = Get-DSEFieldInternalName -ListName "Pays" -Names @("StatutGeo","Statut Geo","Statut")
$existingFrance = Get-PnPListItem -List "Pays" -PageSize 2000 -Fields "Title" -ErrorAction SilentlyContinue | Where-Object { $_["Title"] -eq "France" } | Select-Object -First 1
$frValues = @{ "Title"="France" }
if ($paysFields.IDPays) { $frValues[$paysFields.IDPays] = "PAYS-FR" }
if ($paysFields.CodePays) { $frValues[$paysFields.CodePays] = "FR" }
if ($paysFields.CodeISO2) { $frValues[$paysFields.CodeISO2] = "FR" }
if ($paysFields.StatutGeo) { $frValues[$paysFields.StatutGeo] = "Actif" }
if ($null -eq $existingFrance) { Add-PnPListItem -List "Pays" -Values $frValues | Out-Null; Write-Host "Pays ajoute : France" -ForegroundColor Green }
else { Set-PnPListItem -List "Pays" -Identity $existingFrance.Id -Values $frValues | Out-Null; Write-Host "Pays mis a jour : France" -ForegroundColor Yellow }

function Load-Keys { param([string]$ListName,[string]$FieldName)
    $h = @{}
    $items = Get-PnPListItem -List $ListName -PageSize 5000 -Fields $FieldName -ErrorAction SilentlyContinue
    foreach ($i in $items) { $k = "$($i[$FieldName])"; if(-not [string]::IsNullOrWhiteSpace($k)){ $h[$k] = $true } }
    return $h
}

$regionsExisting = Load-Keys -ListName "Regions" -FieldName "CodeRegion"
$depsExisting = Load-Keys -ListName "Departements" -FieldName "CodeDepartement"
$villesExisting = Load-Keys -ListName "Villes" -FieldName "CodeINSEE"
$cpExisting = Load-Keys -ListName "CodesPostaux" -FieldName "CodePostal"
$relExisting = Load-Keys -ListName "CodesPostauxVilles" -FieldName "CleCPVille"

$regions = @{}
$deps = @{}
$villes = @{}
$cps = @{}
$rels = @{}
foreach ($r in $rows) {
    $codeRegion = Get-DSEValue $r @("code_region","Code_region","codeRegion")
    $nomRegion = Get-DSEValue $r @("nom_region","Nom_region","nomRegion")
    $codeDep = Get-DSEValue $r @("code_departement","Code_departement")
    $nomDep = Get-DSEValue $r @("nom_departement","Nom_departement")
    $codeInsee = Get-DSEValue $r @("code_commune_INSEE","Code_commune_INSEE","Code_commune_insee")
    $nomVille = Get-DSEValue $r @("nom_commune_complet","nom_commune","Nom_commune","nom_commune_postal")
    $nomPostal = Get-DSEValue $r @("nom_commune_postal","Nom_commune")
    $cp = Get-DSEValue $r @("code_postal","Code_postal")
    $lib = Get-DSEValue $r @("libelle_acheminement","Libelle_acheminement")
    $ligne5 = Get-DSEValue $r @("ligne_5","Ligne_5")
    $lat = Get-DSEValue $r @("latitude","Latitude")
    $lon = Get-DSEValue $r @("longitude","Longitude")
    if ($codeRegion) { $regions[$codeRegion] = @{Code=$codeRegion; Nom=$nomRegion} }
    if ($codeDep) { $deps[$codeDep] = @{Code=$codeDep; Nom=$nomDep; CodeRegion=$codeRegion; NomRegion=$nomRegion} }
    if ($codeInsee) { $villes[$codeInsee] = @{Code=$codeInsee; Nom=$nomVille; Postal=$nomPostal; Dep=$codeDep; NomDep=$nomDep; Reg=$codeRegion; NomReg=$nomRegion; Lat=$lat; Lon=$lon} }
    if ($cp) {
        if (-not $cps.ContainsKey($cp)) { $cps[$cp] = @{Code=$cp; Villes=@{}; Deps=@{}; Regs=@{}} }
        if ($codeInsee) { $cps[$cp].Villes[$codeInsee] = $true }
        if ($codeDep) { $cps[$cp].Deps[$codeDep] = $true }
        if ($codeRegion) { $cps[$cp].Regs[$codeRegion] = $true }
    }
    $relKey = "$cp|$codeInsee|$ligne5"
    if ($cp -and $codeInsee) { $rels[$relKey] = @{Key=$relKey; CP=$cp; Insee=$codeInsee; Nom=$nomVille; Lib=$lib; Ligne5=$ligne5; Dep=$codeDep; NomDep=$nomDep; Reg=$codeRegion; NomReg=$nomRegion; Lat=$lat; Lon=$lon} }
}

$batchSize = 100
function Commit-BatchIfNeeded { param($Batch,[ref]$Count,[int]$Limit)
    if ($Count.Value -ge $Limit) { Invoke-PnPBatch -Batch $Batch | Out-Null; $Count.Value = 0; return (New-PnPBatch) }
    return $Batch
}

# Regions
$batch = New-PnPBatch; $count = 0; $regionsAdded=0
foreach($o in $regions.Values){ if($regionsExisting.ContainsKey($o.Code)){continue}; Add-PnPListItem -List "Regions" -Values @{"Title"=$o.Nom;"IDRegion"=("REG-"+$o.Code);"CodeRegion"=$o.Code;"NomRegion"=$o.Nom;"PaysTexte"="France";"StatutGeo"="Actif"} -Batch $batch | Out-Null; $count++; $regionsAdded++; $batch=Commit-BatchIfNeeded $batch ([ref]$count) $batchSize }
if($count -gt 0){Invoke-PnPBatch -Batch $batch | Out-Null}
# Departements
$batch = New-PnPBatch; $count = 0; $depsAdded=0
foreach($o in $deps.Values){ if($depsExisting.ContainsKey($o.Code)){continue}; Add-PnPListItem -List "Departements" -Values @{"Title"=($o.Code+" - "+$o.Nom);"IDDepartement"=("DEP-"+$o.Code);"CodeDepartement"=$o.Code;"NomDepartement"=$o.Nom;"CodeRegion"=$o.CodeRegion;"NomRegion"=$o.NomRegion;"PaysTexte"="France";"StatutGeo"="Actif"} -Batch $batch | Out-Null; $count++; $depsAdded++; $batch=Commit-BatchIfNeeded $batch ([ref]$count) $batchSize }
if($count -gt 0){Invoke-PnPBatch -Batch $batch | Out-Null}
# Villes
$batch = New-PnPBatch; $count = 0; $villesAdded=0
foreach($o in $villes.Values){ if($villesExisting.ContainsKey($o.Code)){continue}; Add-PnPListItem -List "Villes" -Values @{"Title"=$o.Nom;"IDVille"=("VIL-"+$o.Code);"CodeINSEE"=$o.Code;"NomVille"=$o.Nom;"NomPostal"=$o.Postal;"CodeDepartement"=$o.Dep;"NomDepartement"=$o.NomDep;"CodeRegion"=$o.Reg;"NomRegion"=$o.NomReg;"PaysTexte"="France";"Latitude"=$o.Lat;"Longitude"=$o.Lon;"StatutGeo"="Actif"} -Batch $batch | Out-Null; $count++; $villesAdded++; if(($villesAdded % 1000) -eq 0){Write-Host "Villes : $villesAdded ajoutees..." -ForegroundColor DarkCyan}; $batch=Commit-BatchIfNeeded $batch ([ref]$count) $batchSize }
if($count -gt 0){Invoke-PnPBatch -Batch $batch | Out-Null}
# CodesPostaux
$batch = New-PnPBatch; $count = 0; $cpsAdded=0
foreach($o in $cps.Values){ if($cpExisting.ContainsKey($o.Code)){continue}; Add-PnPListItem -List "CodesPostaux" -Values @{"Title"=$o.Code;"IDCodePostal"=("CP-FR-"+$o.Code);"CodePostal"=$o.Code;"PaysTexte"="France";"NombreVilles"=$o.Villes.Keys.Count;"DepartementsAssocies"=($o.Deps.Keys -join ", ");"RegionsAssociees"=($o.Regs.Keys -join ", ");"StatutGeo"="Actif"} -Batch $batch | Out-Null; $count++; $cpsAdded++; $batch=Commit-BatchIfNeeded $batch ([ref]$count) $batchSize }
if($count -gt 0){Invoke-PnPBatch -Batch $batch | Out-Null}
# Relations CP/Villes
$batch = New-PnPBatch; $count = 0; $relsAdded=0
foreach($o in $rels.Values){ if($relExisting.ContainsKey($o.Key)){continue}; Add-PnPListItem -List "CodesPostauxVilles" -Values @{"Title"=($o.CP+" - "+$o.Nom);"IDCPVille"=("CPV-FR-"+$o.CP+"-"+$o.Insee);"CleCPVille"=$o.Key;"CodePostal"=$o.CP;"CodeINSEE"=$o.Insee;"NomVille"=$o.Nom;"LibelleAcheminement"=$o.Lib;"Ligne5"=$o.Ligne5;"CodeDepartement"=$o.Dep;"NomDepartement"=$o.NomDep;"CodeRegion"=$o.Reg;"NomRegion"=$o.NomReg;"PaysTexte"="France";"Latitude"=$o.Lat;"Longitude"=$o.Lon;"StatutGeo"="Actif"} -Batch $batch | Out-Null; $count++; $relsAdded++; if(($relsAdded % 1000) -eq 0){Write-Host "CP/Villes : $relsAdded ajoutees..." -ForegroundColor DarkCyan}; $batch=Commit-BatchIfNeeded $batch ([ref]$count) $batchSize }
if($count -gt 0){Invoke-PnPBatch -Batch $batch | Out-Null}
$msg = "Ajouts V1.1 - Regions: $regionsAdded, Departements: $depsAdded, Villes: $villesAdded, CodesPostaux: $cpsAdded, Relations CP/Villes: $relsAdded."
Write-Host $msg -ForegroundColor Green
Add-DSEJournalAction -Action "Import geographie France V1.1" -Objet "Geographie" -Resultat "OK" -Message $msg
