﻿param([string]$Root)
. "$PSScriptRoot\_common.ps1"
Connect-DSESharePoint
function Ensure-View { param([string]$ListName,[string]$ViewName,[string[]]$Fields)
    try {
        $existingFields = @()
        $listFields = Get-PnPField -List $ListName
        foreach ($f in $Fields) { if ($listFields | Where-Object { $_.InternalName -eq $f }) { $existingFields += $f } }
        $v = Get-PnPView -List $ListName -Identity $ViewName -ErrorAction SilentlyContinue
        if ($null -eq $v) { Add-PnPView -List $ListName -Title $ViewName -Fields $existingFields -SetAsDefault | Out-Null; Write-Host "Vue creee : $ListName / $ViewName" -ForegroundColor Green }
        else { Set-PnPView -List $ListName -Identity $ViewName -Fields $existingFields -SetAsDefault | Out-Null; Write-Host "Vue mise a jour : $ListName / $ViewName" -ForegroundColor Yellow }
    } catch { Write-Host "Vue non modifiee : $ListName / $ViewName / $($_.Exception.Message)" -ForegroundColor Yellow }
}
Ensure-View -ListName "Regions" -ViewName "Regions Admin" -Fields @("Title","IDRegion","CodeRegion","NomRegion","PaysTexte","StatutGeo")
Ensure-View -ListName "Departements" -ViewName "Departements Admin" -Fields @("Title","IDDepartement","CodeDepartement","NomDepartement","CodeRegion","NomRegion","PaysTexte","StatutGeo")
Ensure-View -ListName "Villes" -ViewName "Villes Admin" -Fields @("Title","IDVille","CodeINSEE","NomVille","CodeDepartement","NomDepartement","CodeRegion","NomRegion","PaysTexte")
Ensure-View -ListName "CodesPostaux" -ViewName "Codes Postaux Admin" -Fields @("Title","IDCodePostal","CodePostal","PaysTexte","NombreVilles","DepartementsAssocies","RegionsAssociees","StatutGeo")
Ensure-View -ListName "CodesPostauxVilles" -ViewName "CP Villes Admin" -Fields @("Title","IDCPVille","CodePostal","CodeINSEE","NomVille","CodeDepartement","NomDepartement","CodeRegion","NomRegion","PaysTexte")
Add-DSEJournalAction -Action "Creation vues geographie V1.1" -Objet "Geographie" -Resultat "OK" -Message "Vues admin geographiques creees ou mises a jour."
