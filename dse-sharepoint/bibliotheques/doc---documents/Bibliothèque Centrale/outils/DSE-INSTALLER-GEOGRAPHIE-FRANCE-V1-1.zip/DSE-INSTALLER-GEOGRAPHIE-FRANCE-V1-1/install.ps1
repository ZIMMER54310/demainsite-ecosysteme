﻿$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$LogDir = Join-Path $Root "logs"
if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Force -Path $LogDir | Out-Null }
$Stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$Log = Join-Path $LogDir "DSE-GeographieFrance-V1-1-$Stamp.log"
Start-Transcript -Path $Log -Append | Out-Null
try {
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host " DSE - GEOGRAPHIE FRANCE V1.1" -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    $Steps = @(
        "steps\\01-connexion.ps1",
        "steps\\02-creer-listes-geographie.ps1",
        "steps\\03-telecharger-source.ps1",
        "steps\\04-importer-geographie.ps1",
        "steps\\05-creer-vues.ps1",
        "steps\\06-controle-final.ps1"
    )
    foreach ($StepRel in $Steps) {
        $Step = Join-Path $Root $StepRel
        if (-not (Test-Path $Step)) { throw "Fichier manquant : $Step" }
        Write-Host ""; Write-Host "Execution : $StepRel" -ForegroundColor Cyan
        & $Step -Root $Root
        Write-Host "OK : $StepRel" -ForegroundColor Green
    }
    Write-Host ""; Write-Host "INSTALLATION GEOGRAPHIE FRANCE V1.1 TERMINEE" -ForegroundColor Green
}
catch {
    Write-Host "ERREUR : $($_.Exception.Message)" -ForegroundColor Red
    throw
}
finally { Stop-Transcript | Out-Null }
