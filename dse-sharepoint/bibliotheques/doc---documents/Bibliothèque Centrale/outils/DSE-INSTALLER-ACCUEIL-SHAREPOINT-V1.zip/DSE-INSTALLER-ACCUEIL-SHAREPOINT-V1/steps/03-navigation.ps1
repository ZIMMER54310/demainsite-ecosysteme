﻿param([string]$Root)
. "$PSScriptRoot\_common.ps1"
Connect-DSESharePoint
$web = Get-PnPWeb
$siteRel = $web.ServerRelativeUrl
if ($siteRel -eq "/") { $siteRel = "" }
$pageUrl = "$siteRel/SitePages/$script:PageName"
try {
    $existingNav = Get-PnPNavigationNode -Location QuickLaunch | Where-Object { $_.Title -eq "Accueil DemainSite" } | Select-Object -First 1
    if ($null -eq $existingNav) {
        Add-PnPNavigationNode -Title "Accueil DemainSite" -Url $pageUrl -Location QuickLaunch -First | Out-Null
        Write-Host "Lien ajoute au menu : Accueil DemainSite" -ForegroundColor Green
    } else {
        Write-Host "Lien menu deja present : Accueil DemainSite" -ForegroundColor DarkGreen
    }
} catch { Write-Host "Navigation non modifiee : $($_.Exception.Message)" -ForegroundColor Yellow }
try {
    Set-PnPHomePage -RootFolderRelativeUrl "SitePages/$script:PageName"
    Write-Host "Accueil DemainSite defini comme page d accueil." -ForegroundColor Green
} catch { Write-Host "Page non definie comme accueil automatiquement : $($_.Exception.Message)" -ForegroundColor Yellow }
Add-DSEJournalAction -Action "Navigation accueil SharePoint" -Objet $script:PageName -Resultat "OK" -Message "Lien menu et page accueil traites."
