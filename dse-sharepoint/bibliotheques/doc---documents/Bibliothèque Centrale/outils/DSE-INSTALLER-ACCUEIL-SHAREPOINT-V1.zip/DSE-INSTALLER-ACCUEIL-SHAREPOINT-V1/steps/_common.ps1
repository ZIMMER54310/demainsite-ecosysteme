﻿$script:SpUrl = "https://blogssite.sharepoint.com/sites/Bibliotheque"
$script:ClientId = "5d607413-77c5-47b2-975a-eaca6827921c"
$script:Tenant = "demainsite.com"
$script:PageName = "Accueil-DemainSite-Ecosysteme.aspx"
$script:PageTitle = "Accueil DemainSite Ecosysteme"

function Connect-DSESharePoint {
    try {
        $web = Get-PnPWeb -ErrorAction Stop
        Write-Host "Connexion SharePoint active : $($web.Url)" -ForegroundColor Green
    } catch {
        Write-Host "Connexion SharePoint absente. Connexion DeviceLogin..." -ForegroundColor Yellow
        Connect-PnPOnline -Url $script:SpUrl -ClientId $script:ClientId -Tenant $script:Tenant -DeviceLogin
        $web = Get-PnPWeb -ErrorAction Stop
        Write-Host "Connexion SharePoint OK : $($web.Url)" -ForegroundColor Green
    }
}

function Get-DSEListUrl {
    param([string]$ListName)
    $list = Get-PnPList -Identity $ListName -ErrorAction SilentlyContinue
    if ($null -eq $list) { return "#" }
    return $list.RootFolder.ServerRelativeUrl
}

function Add-DSEJournalAction {
    param([string]$Action,[string]$Objet,[string]$Resultat,[string]$Message)
    try {
        $list = Get-PnPList -Identity "JournalActions" -ErrorAction SilentlyContinue
        if ($null -eq $list) { return }
        $items = Get-PnPListItem -List "JournalActions" -PageSize 2000 -Fields "IDJournal" -ErrorAction SilentlyContinue
        $max = 0
        foreach ($item in $items) {
            $v = "$($item['IDJournal'])"
            if ($v -match "^JRN-([0-9]+)$") { $n = [int]$matches[1]; if ($n -gt $max) { $max = $n } }
        }
        $id = ("JRN-{0:D6}" -f ($max + 1))
        Add-PnPListItem -List "JournalActions" -Values @{
            "Title"=$Action; "IDJournal"=$id; "DateAction"=Get-Date; "Source"="PowerShell"; "Objet"=$Objet; "Resultat"=$Resultat; "Message"=$Message; "Utilisateur"=$env:USERNAME
        } | Out-Null
    } catch { Write-Host "Journal non ecrit : $($_.Exception.Message)" -ForegroundColor Yellow }
}

function New-CardHtml {
    param([string]$Title,[string]$Sub,[string]$Url,[string]$Color)
    return "<a href='$Url' style='text-decoration:none;color:#172033;'><div style='background:#ffffff;border-left:7px solid $Color;border-radius:16px;padding:18px;min-height:112px;box-shadow:0 2px 8px rgba(15,23,42,.10);'><div style='font-size:21px;font-weight:750;margin-bottom:8px;'>$Title</div><div style='font-size:14px;line-height:1.45;color:#475569;'>$Sub</div></div></a>"
}

function New-LinkHtml {
    param([string]$Title,[string]$Url)
    return "<a href='$Url' style='display:inline-block;margin:5px 7px 5px 0;padding:9px 12px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:999px;color:#334155;text-decoration:none;font-size:13px;'>$Title</a>"
}
