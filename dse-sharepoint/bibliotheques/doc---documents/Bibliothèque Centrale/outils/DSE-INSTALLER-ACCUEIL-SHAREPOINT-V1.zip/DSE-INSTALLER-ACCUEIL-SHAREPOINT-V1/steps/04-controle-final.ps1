﻿param([string]$Root)
. "$PSScriptRoot\_common.ps1"
Connect-DSESharePoint
$web = Get-PnPWeb
$siteRel = $web.ServerRelativeUrl
if ($siteRel -eq "/") { $siteRel = "" }
$pageUrl = "$siteRel/SitePages/$script:PageName"
$page = Get-PnPFile -Url $pageUrl -ErrorAction SilentlyContinue
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " CONTROLE FINAL ACCUEIL SHAREPOINT" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
if ($null -ne $page) { Write-Host "Page accueil : OK - $pageUrl" -ForegroundColor Green } else { Write-Host "Page accueil : ABSENTE" -ForegroundColor Red }
Write-Host "Ouvre le menu SharePoint > Accueil DemainSite." -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Add-DSEJournalAction -Action "Controle final accueil SharePoint" -Objet $script:PageName -Resultat "OK" -Message "Controle final execute."
