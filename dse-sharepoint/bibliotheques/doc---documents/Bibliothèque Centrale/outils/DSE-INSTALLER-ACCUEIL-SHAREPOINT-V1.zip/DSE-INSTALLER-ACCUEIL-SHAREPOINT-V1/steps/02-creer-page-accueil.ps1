﻿param([string]$Root)
. "$PSScriptRoot\_common.ps1"
Connect-DSESharePoint

$web = Get-PnPWeb
$siteRel = $web.ServerRelativeUrl
if ($siteRel -eq "/") { $siteRel = "" }
$pageUrl = "$siteRel/SitePages/$script:PageName"

# Liens metier
$uRelations = Get-DSEListUrl "Relations"
$uClients = Get-DSEListUrl "Clients"
$uSites = Get-DSEListUrl "Sites"
$uProjets = Get-DSEListUrl "Projets"
$uDomaines = Get-DSEListUrl "Domaines"
$uMedias = Get-DSEListUrl "Medias"
$uPages = Get-DSEListUrl "Pages"
$uUtilisateurs = Get-DSEListUrl "Utilisateurs"
# Administration
$uCatalogueListes = Get-DSEListUrl "CatalogueListes"
$uCatalogueInstallateurs = Get-DSEListUrl "CatalogueInstallateurs"
$uJournalActions = Get-DSEListUrl "JournalActions"
$uJournalErreurs = Get-DSEListUrl "JournalErreurs"
$uProcedures = Get-DSEListUrl "Procedures"
# Referentiels
$uCivilites = Get-DSEListUrl "Civilites"
$uStatuts = Get-DSEListUrl "Statuts"
$uTypesRelations = Get-DSEListUrl "TypesRelations"
$uTypesSites = Get-DSEListUrl "TypesSites"
$uTypesDomaines = Get-DSEListUrl "TypesDomaines"
$uTypesProjets = Get-DSEListUrl "TypesProjets"
$uTypesMedia = Get-DSEListUrl "TypesMedia"
$uCategoriesMedia = Get-DSEListUrl "CategoriesMedia"
$uCategoriesPages = Get-DSEListUrl "CategoriesPages"
$uLicences = Get-DSEListUrl "Licences"
$uRoles = Get-DSEListUrl "RolesUtilisateurs"
$uPays = Get-DSEListUrl "Pays"
$uLangues = Get-DSEListUrl "Langues"

$cardsMetier = ""
$cardsMetier += New-CardHtml "Relations" "Point de depart : relation, client, site, projet et contexte." $uRelations "#2563eb"
$cardsMetier += New-CardHtml "Clients" "Fiches clients, associations, societes et structures." $uClients "#16a34a"
$cardsMetier += New-CardHtml "Sites" "Sites WordPress, sites clients, sites actifs et domaines." $uSites "#7c3aed"
$cardsMetier += New-CardHtml "Projets" "Projets clients, internes, supports, affiches et Microsoft 365." $uProjets "#f97316"
$cardsMetier += New-CardHtml "Medias" "Images, videos, audios, documents, logos et bannieres." $uMedias "#dc2626"
$cardsMetier += New-CardHtml "Pages" "Pages WordPress importees et pages reutilisables." $uPages "#0891b2"
$cardsMetier += New-CardHtml "Domaines" "Domaines principaux, alias, redirections et rattachements." $uDomaines "#0f766e"
$cardsMetier += New-CardHtml "Utilisateurs" "Collaborateurs, clients, responsables et futurs droits." $uUtilisateurs "#64748b"

$cardsAdmin = ""
$cardsAdmin += New-CardHtml "Catalogue des listes" "Carte de toutes les listes : role, famille, visibilite, anti-doublon." $uCatalogueListes "#111827"
$cardsAdmin += New-CardHtml "Installateurs" "Packs DSE, scripts, versions et execution par RUN-DSE." $uCatalogueInstallateurs "#9333ea"
$cardsAdmin += New-CardHtml "Journal actions" "Trace des actions reussies et controle des automatisations." $uJournalActions "#16a34a"
$cardsAdmin += New-CardHtml "Journal erreurs" "Erreurs a analyser, sans suppression ni oubli." $uJournalErreurs "#dc2626"
$cardsAdmin += New-CardHtml "Procedures" "Procedures officielles, reprise, securite et anti-regression." $uProcedures "#475569"

$refs = ""
$refs += New-LinkHtml "Civilites" $uCivilites
$refs += New-LinkHtml "Statuts" $uStatuts
$refs += New-LinkHtml "Types relations" $uTypesRelations
$refs += New-LinkHtml "Types sites" $uTypesSites
$refs += New-LinkHtml "Types domaines" $uTypesDomaines
$refs += New-LinkHtml "Types projets" $uTypesProjets
$refs += New-LinkHtml "Types medias" $uTypesMedia
$refs += New-LinkHtml "Categories medias" $uCategoriesMedia
$refs += New-LinkHtml "Categories pages" $uCategoriesPages
$refs += New-LinkHtml "Licences" $uLicences
$refs += New-LinkHtml "Roles utilisateurs" $uRoles
$refs += New-LinkHtml "Pays" $uPays
$refs += New-LinkHtml "Langues" $uLangues

$html = @"
<div style="font-family:Segoe UI,Arial,sans-serif;background:#f4f7fb;padding:26px;border-radius:22px;">
  <div style="background:linear-gradient(135deg,#0f172a,#1d4ed8);color:white;border-radius:22px;padding:28px;margin-bottom:20px;box-shadow:0 4px 14px rgba(15,23,42,.20);">
    <div style="font-size:32px;font-weight:800;">DemainSite Ecosysteme</div>
    <div style="font-size:19px;margin-top:6px;">Accueil utilisateur - Bibliotheque Centrale</div>
    <div style="font-size:14px;margin-top:12px;opacity:.92;">Travailler simplement : choisir un domaine, chercher, ouvrir, puis agir. Les listes techniques restent disponibles dans Administration.</div>
  </div>

  <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:22px;">
    <div style="background:white;border-radius:14px;padding:16px;text-align:center;box-shadow:0 1px 6px rgba(0,0,0,.08);"><div style="font-size:24px;font-weight:800;color:#2563eb;">Metier</div><div style="font-size:13px;color:#475569;">Clients, sites, projets</div></div>
    <div style="background:white;border-radius:14px;padding:16px;text-align:center;box-shadow:0 1px 6px rgba(0,0,0,.08);"><div style="font-size:24px;font-weight:800;color:#16a34a;">Referentiels</div><div style="font-size:13px;color:#475569;">Filtres SharePoint et WordPress</div></div>
    <div style="background:white;border-radius:14px;padding:16px;text-align:center;box-shadow:0 1px 6px rgba(0,0,0,.08);"><div style="font-size:24px;font-weight:800;color:#9333ea;">Installateurs</div><div style="font-size:13px;color:#475569;">Packs RUN-DSE</div></div>
    <div style="background:white;border-radius:14px;padding:16px;text-align:center;box-shadow:0 1px 6px rgba(0,0,0,.08);"><div style="font-size:24px;font-weight:800;color:#dc2626;">Journaux</div><div style="font-size:13px;color:#475569;">Actions et erreurs</div></div>
  </div>

  <div style="background:#fff7ed;border-left:7px solid #f97316;border-radius:16px;padding:18px;margin-bottom:24px;">
    <div style="font-size:20px;font-weight:800;">Regle de travail</div>
    <div style="font-size:15px;margin-top:7px;color:#334155;">Avant toute creation : rechercher dans CatalogueListes et les referentiels. Si une valeur existe deja, on reutilise. Si la liste est trop large, on filtre. On ne cree pas de doublon.</div>
  </div>

  <h2 style="margin:18px 0 10px 0;color:#0f172a;">Travail principal</h2>
  <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:14px;">
    $cardsMetier
  </div>

  <h2 style="margin:28px 0 10px 0;color:#0f172a;">Administration</h2>
  <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:14px;">
    $cardsAdmin
  </div>

  <h2 style="margin:28px 0 10px 0;color:#0f172a;">Referentiels et futurs filtres WordPress</h2>
  <div style="background:white;border-radius:16px;padding:18px;box-shadow:0 1px 6px rgba(0,0,0,.08);">
    <div style="font-size:15px;color:#475569;margin-bottom:10px;">Tables de reference reutilisables. Elles alimenteront les filtres SharePoint, WordPress et PascARA IA.</div>
    $refs
  </div>

  <h2 style="margin:28px 0 10px 0;color:#0f172a;">PascARA IA - principe</h2>
  <div style="background:#ecfeff;border-left:7px solid #0891b2;border-radius:16px;padding:18px;">
    <div style="font-size:16px;color:#334155;line-height:1.7;">PascARA doit guider, chercher dans les listes existantes, proposer la reutilisation, journaliser les actions et signaler les erreurs. L utilisateur travaille depuis cet accueil, pas depuis le menu brut des listes.</div>
  </div>
</div>
"@

# Supprimer ancienne version de la page dans la corbeille si elle existe, puis recreer proprement
try {
    $old = Get-PnPFile -Url $pageUrl -ErrorAction SilentlyContinue
    if ($null -ne $old) {
        Remove-PnPFile -ServerRelativeUrl $pageUrl -Recycle -Force
        Write-Host "Ancienne page Accueil envoyee en corbeille : $script:PageName" -ForegroundColor Yellow
    }
} catch { Write-Host "Ancienne page non trouvee ou non recyclable." -ForegroundColor Yellow }

$page = Add-PnPPage -Name $script:PageName -LayoutType Article
try { Set-PnPPage -Identity $script:PageName -Title $script:PageTitle -CommentsEnabled:$false | Out-Null } catch {}
Add-PnPPageTextPart -Page $page -Text $html | Out-Null
$page.Publish()
Write-Host "Page creee et publiee : $script:PageName" -ForegroundColor Green
Add-DSEJournalAction -Action "Creation accueil SharePoint" -Objet $script:PageName -Resultat "OK" -Message "Accueil ergonomique SharePoint cree et publie."
