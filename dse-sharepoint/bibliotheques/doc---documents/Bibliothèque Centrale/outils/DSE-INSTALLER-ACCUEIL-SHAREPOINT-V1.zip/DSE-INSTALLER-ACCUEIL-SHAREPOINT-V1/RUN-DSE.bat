﻿@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo DEMAINSITE ECOSYSTEME - ACCUEIL SHAREPOINT V1
echo ============================================================
echo.
pwsh -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
echo.
echo Fin de l execution. Consulte le dossier logs si besoin.
pause
