﻿DSE-INSTALLER-ACCUEIL-SHAREPOINT-V1

But : creer une page d'accueil SharePoint simple, ergonomique et utilisable par un humain.

Ce pack :
- cree la page Accueil-DemainSite-Ecosysteme.aspx,
- ajoute des cartes metier,
- ajoute des cartes administration,
- ajoute les referentiels comme liens propres,
- ajoute le lien Accueil DemainSite au menu,
- tente de definir la page comme page d'accueil,
- ecrit dans JournalActions si la liste existe.

Utilisation :
1. Placer ce dossier dans DemainSite ecosysteme - Bibliotheque Centrale / OUTILS / INSTALLATEURS.
2. Double-cliquer RUN-DSE.bat.
3. Verifier dans SharePoint : Accueil DemainSite.

Aucune suppression definitive.
L'ancienne page du meme nom est envoyee en corbeille si elle existe.
Aucune modification WordPress.
