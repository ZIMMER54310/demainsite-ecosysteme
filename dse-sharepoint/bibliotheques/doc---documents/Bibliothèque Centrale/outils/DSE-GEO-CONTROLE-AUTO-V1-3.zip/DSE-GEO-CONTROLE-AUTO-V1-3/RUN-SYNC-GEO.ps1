# ============================================================
# DEMAINSITE ECOSYSTEME - SYNCHRONISATION GEOGRAPHIE SECURISEE
# V1.3 - squelette pret pour evolution
# ============================================================

param(
    [ValidateSet("AuditOnly","AutoUpdate")]
    [string]$Mode = "AuditOnly"
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
. "$Root\CONFIG.ps1"
. "$Root\steps\DSE-Common.ps1"

$cfg = $global:DSE_GEO_Config
$runId = Get-Date -Format "yyyyMMdd-HHmmss"
$logFile = Join-Path $Root "logs\DSE-GEO-SYNC-$runId.log"
Start-Transcript -Path $logFile -Force | Out-Null

try {
    Write-DSETitle "DEMAINSITE - SYNCHRONISATION GEOGRAPHIE SECURISEE V1.3"
    Write-Host "Mode : $Mode" -ForegroundColor Cyan
    Write-Host "Source officielle referencee : $($cfg.SourceCogPageUrl)" -ForegroundColor Cyan

    Connect-DSESharePoint -SiteUrl $cfg.SiteUrl
    Ensure-DSEJournalList -ListName $cfg.ListJournalActions
    Ensure-DSEJournalList -ListName $cfg.ListJournalErreurs

    Write-Host "Cette version securisee ne supprime rien." -ForegroundColor Green
    Write-Host "Si une donnee disparait d'une source future, elle doit etre archivee et journalisee." -ForegroundColor Green
    Write-Host "Pour l'instant, lance le controle complet avec RUN-CONTROLE-GEO.ps1." -ForegroundColor Yellow

    Add-DSEJournal -ListName $cfg.ListJournalActions -Title "Sync geographie $runId" -TypeJournal "Preparation" -Module "Geographie" -Objet "Synchronisation" -Message "Squelette de synchronisation execute en mode $Mode. Aucune suppression." -Statut "Prepare"
}
catch {
    Write-Host "ERREUR SYNC : $($_.Exception.Message)" -ForegroundColor Red
    try { Add-DSEJournal -ListName $cfg.ListJournalErreurs -Title "Sync geographie $runId" -TypeJournal "Erreur" -Module "Geographie" -Objet "Synchronisation" -Message $_.Exception.Message -Statut "Erreur" } catch {}
}
finally {
    Stop-Transcript | Out-Null
}
