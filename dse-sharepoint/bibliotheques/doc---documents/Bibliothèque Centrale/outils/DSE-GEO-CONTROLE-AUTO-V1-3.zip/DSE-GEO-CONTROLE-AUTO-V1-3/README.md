# DSE-GEO-CONTROLE-AUTO-V1.3

Pack DemainSite Ecosysteme pour controler le referentiel geographique SharePoint.

## Objectif

Ce pack sert a controler et surveiller les listes :

- Pays
- Regions
- Departements
- Villes
- CodesPostaux
- CodesPostauxVilles

Il cree des vues de controle, compte les elements, detecte les champs vides et journalise les anomalies.

## Regle de securite validee

Aucune suppression automatique.

Si une commune, un code postal ou une relation disparait d'une source officielle future, l'objet doit etre :

- conserve dans SharePoint,
- marque comme archive ou a verifier,
- inscrit dans Journal actions ou Journal erreurs.

## Fichiers principaux

- RUN-CONTROLE-GEO.ps1 : controle manuel complet.
- INSTALL-TACHE-MENSUELLE.ps1 : installe une verification mensuelle Windows.
- RUN-SYNC-GEO.ps1 : base de synchronisation future, securisee, sans suppression.
- CONFIG.ps1 : parametres du site, listes et seuils.
- steps/DSE-Common.ps1 : fonctions communes.

## Utilisation rapide

1. Extraire le ZIP dans un dossier local.
2. Ouvrir PowerShell 7.
3. Aller dans le dossier du pack.
4. Lancer :

```powershell
.\RUN-CONTROLE-GEO.ps1
```

## Installer la verification mensuelle

```powershell
.\INSTALL-TACHE-MENSUELLE.ps1
```

La tache Windows lance le controle chaque mois. Elle peut necessiter que la connexion PnP soit deja disponible pour l'utilisateur Windows.

## Important

Le pack ne remplace pas la verification humaine de Pascal. Il prepare le controle, journalise et signale les ecarts.
