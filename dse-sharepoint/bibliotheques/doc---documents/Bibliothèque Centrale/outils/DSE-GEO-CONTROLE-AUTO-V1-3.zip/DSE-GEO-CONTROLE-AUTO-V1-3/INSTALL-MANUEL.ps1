# ============================================================
# DEMAINSITE ECOSYSTEME - LANCEMENT MANUEL SIMPLE
# ============================================================

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
& "$Root\RUN-CONTROLE-GEO.ps1" -Mode AuditOnly
