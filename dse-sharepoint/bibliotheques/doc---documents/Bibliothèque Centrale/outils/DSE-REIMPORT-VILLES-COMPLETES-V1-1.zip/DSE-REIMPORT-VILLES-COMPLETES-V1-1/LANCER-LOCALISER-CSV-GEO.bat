@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title DemainSite - Localiser CSV Geo

echo ============================================================
echo  DEMAINSITE ECOSYSTEME - LOCALISER CSV GEOGRAPHIE
echo ============================================================
echo.

where pwsh >nul 2>nul
if %errorlevel%==0 (
    pwsh -NoProfile -ExecutionPolicy Bypass -File "%~dp0LOCALISER-CSV-GEO.ps1"
) else (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0LOCALISER-CSV-GEO.ps1"
)

echo.
pause
