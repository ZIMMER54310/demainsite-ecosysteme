@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title DemainSite - Audit Vues Communes A-Z

echo ============================================================
echo  DEMAINSITE ECOSYSTEME - AUDIT VUES COMMUNES A-Z
echo ============================================================
echo.
where pwsh >nul 2>nul
if %errorlevel%==0 (
    pwsh -NoProfile -ExecutionPolicy Bypass -File "%~dp0RUN-CREER-VUES-COMMUNES-A-Z.ps1" -Mode AuditOnly
) else (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0RUN-CREER-VUES-COMMUNES-A-Z.ps1" -Mode AuditOnly
)

echo.
pause
