﻿param([string]$Root)
. "$PSScriptRoot\_common.ps1"
Connect-DSESharePoint
$csvPath = Join-Path $Root "data\communes-departement-region.csv"
if (-not (Test-Path $csvPath)) { throw "CSV source absent : $csvPath" }
Write-Host "Lecture CSV : $csvPath" -ForegroundColor Cyan
$rows = Import-Csv -Path $csvPath
Write-Host "Lignes source : $($rows.Count)" -ForegroundColor Cyan

# Pays France
$existingFrance = Get-PnPListItem -List "Pays" -PageSize 2000 -Fields "Title","CodePays" | Where-Object { $_["Title"] -eq "France" -or $_["CodePays"] -eq "FR" } | Select-Object -First 1
if ($null -eq $existingFrance) {
    Add-PnPListItem -List "Pays" -Values @{ "Title"="France"; "IDPays"="PAYS-FR"; "CodePays"="FR"; "ISO2"="FR"; "Statut"="Actif" } | Out-Null
    Write-Host "Pays ajoute : France" -ForegroundColor Green
}

# Index existants
function Load-Keys { param([string]$ListName,[string]$FieldName)
    $h = @{}
    $items = Get-PnPListItem -List $ListName -PageSize 5000 -Fields $FieldName -ErrorAction SilentlyContinue
    foreach ($i in $items) { $k = "$($i[$FieldName])"; if(-not [string]::IsNullOrWhiteSpace($k)){ $h[$k] = $true } }
    return $h
}
$regionsExisting = Load-Keys -ListName "Regions" -FieldName "CodeRegion"
$depsExisting = Load-Keys -ListName "Departements" -FieldName "CodeDepartement"
$villesExisting = Load-Keys -ListName "Villes" -FieldName "CodeINSEE"
$cpExisting = Load-Keys -ListName "CodesPostaux" -FieldName "CodePostal"
$relExisting = Load-Keys -ListName "CodesPostauxVilles" -FieldName "CleCPVille"

$regions = @{}
$deps = @{}
$villes = @{}
$cps = @{}
$rels = @{}
foreach ($r in $rows) {
    $codeRegion = Get-DSEValue $r @("code_region","Code_region","codeRegion")
    $nomRegion = Get-DSEValue $r @("nom_region","Nom_region","nomRegion")
    $codeDep = Get-DSEValue $r @("code_departement","Code_departement","code_departement")
    $nomDep = Get-DSEValue $r @("nom_departement","Nom_departement")
    $codeInsee = Get-DSEValue $r @("code_commune_INSEE","Code_commune_INSEE","Code_commune_insee")
    $nomVille = Get-DSEValue $r @("nom_commune_complet","nom_commune","Nom_commune","nom_commune_postal")
    $nomPostal = Get-DSEValue $r @("nom_commune_postal","Nom_commune")
    $cp = Get-DSEValue $r @("code_postal","Code_postal")
    $lib = Get-DSEValue $r @("libelle_acheminement","Libelle_acheminement")
    $ligne5 = Get-DSEValue $r @("ligne_5","Ligne_5")
    $lat = Get-DSEValue $r @("latitude","Latitude")
    $lon = Get-DSEValue $r @("longitude","Longitude")
    if (-not [string]::IsNullOrWhiteSpace($codeRegion)) { $regions[$codeRegion] = @{Code=$codeRegion; Nom=$nomRegion} }
    if (-not [string]::IsNullOrWhiteSpace($codeDep)) { $deps[$codeDep] = @{Code=$codeDep; Nom=$nomDep; CodeRegion=$codeRegion; NomRegion=$nomRegion} }
    if (-not [string]::IsNullOrWhiteSpace($codeInsee)) { $villes[$codeInsee] = @{Code=$codeInsee; Nom=$nomVille; Postal=$nomPostal; Dep=$codeDep; NomDep=$nomDep; Reg=$codeRegion; NomReg=$nomRegion; Lat=$lat; Lon=$lon} }
    if (-not [string]::IsNullOrWhiteSpace($cp)) {
        if (-not $cps.ContainsKey($cp)) { $cps[$cp] = @{Code=$cp; Villes=@{}; Deps=@{}; Regs=@{}} }
        if (-not [string]::IsNullOrWhiteSpace($codeInsee)) { $cps[$cp].Villes[$codeInsee] = $true }
        if (-not [string]::IsNullOrWhiteSpace($codeDep)) { $cps[$cp].Deps[$codeDep] = $true }
        if (-not [string]::IsNullOrWhiteSpace($codeRegion)) { $cps[$cp].Regs[$codeRegion] = $true }
    }
    $relKey = "$cp|$codeInsee|$ligne5"
    if (-not [string]::IsNullOrWhiteSpace($cp) -and -not [string]::IsNullOrWhiteSpace($codeInsee)) {
        $rels[$relKey] = @{Key=$relKey; CP=$cp; Insee=$codeInsee; Nom=$nomVille; Lib=$lib; Ligne5=$ligne5; Dep=$codeDep; NomDep=$nomDep; Reg=$codeRegion; NomReg=$nomRegion; Lat=$lat; Lon=$lon}
    }
}

$batchSize = 100
function Add-BatchItems { param([string]$ListName,[array]$Collection,[hashtable]$Existing,[scriptblock]$BuildValues,[string]$KeyName)
    $batch = New-PnPBatch
    $count = 0; $added = 0
    foreach ($obj in $Collection) {
        $key = & $KeyName $obj
        if ($Existing.ContainsKey($key)) { continue }
        $values = & $BuildValues $obj
        Add-PnPListItem -List $ListName -Values $values -Batch $batch | Out-Null
        $count++; $added++
        if ($count -ge $batchSize) { Invoke-PnPBatch -Batch $batch | Out-Null; $batch = New-PnPBatch; $count = 0; Write-Host "$ListName : $added ajouts..." -ForegroundColor DarkCyan }
    }
    if ($count -gt 0) { Invoke-PnPBatch -Batch $batch | Out-Null }
    return $added
}

$regionsAdded = Add-BatchItems -ListName "Regions" -Collection @($regions.Values) -Existing $regionsExisting -KeyName { param($o) $o.Code } -BuildValues { param($o) @{"Title"=$o.Nom; "IDRegion"=("REG-"+$o.Code); "CodeRegion"=$o.Code; "NomRegion"=$o.Nom; "PaysTexte"="France"; "Statut"="Actif"} }
$depsAdded = Add-BatchItems -ListName "Departements" -Collection @($deps.Values) -Existing $depsExisting -KeyName { param($o) $o.Code } -BuildValues { param($o) @{"Title"=($o.Code+" - "+$o.Nom); "IDDepartement"=("DEP-"+$o.Code); "CodeDepartement"=$o.Code; "NomDepartement"=$o.Nom; "CodeRegion"=$o.CodeRegion; "NomRegion"=$o.NomRegion; "PaysTexte"="France"; "Statut"="Actif"} }
$villesAdded = Add-BatchItems -ListName "Villes" -Collection @($villes.Values) -Existing $villesExisting -KeyName { param($o) $o.Code } -BuildValues { param($o) @{"Title"=$o.Nom; "IDVille"=("VIL-"+$o.Code); "CodeINSEE"=$o.Code; "NomVille"=$o.Nom; "NomPostal"=$o.Postal; "CodeDepartement"=$o.Dep; "NomDepartement"=$o.NomDep; "CodeRegion"=$o.Reg; "NomRegion"=$o.NomReg; "PaysTexte"="France"; "Latitude"=$o.Lat; "Longitude"=$o.Lon; "Statut"="Actif"} }
$cpsAdded = Add-BatchItems -ListName "CodesPostaux" -Collection @($cps.Values) -Existing $cpExisting -KeyName { param($o) $o.Code } -BuildValues { param($o) @{"Title"=$o.Code; "IDCodePostal"=("CP-FR-"+$o.Code); "CodePostal"=$o.Code; "PaysTexte"="France"; "NombreVilles"=$o.Villes.Keys.Count; "DepartementsAssocies"=($o.Deps.Keys -join ", "); "RegionsAssociees"=($o.Regs.Keys -join ", "); "Statut"="Actif"} }
$relsAdded = Add-BatchItems -ListName "CodesPostauxVilles" -Collection @($rels.Values) -Existing $relExisting -KeyName { param($o) $o.Key } -BuildValues { param($o) @{"Title"=($o.CP+" - "+$o.Nom); "IDCPVille"=("CPV-FR-"+$o.CP+"-"+$o.Insee); "CleCPVille"=$o.Key; "CodePostal"=$o.CP; "CodeINSEE"=$o.Insee; "NomVille"=$o.Nom; "LibelleAcheminement"=$o.Lib; "Ligne5"=$o.Ligne5; "CodeDepartement"=$o.Dep; "NomDepartement"=$o.NomDep; "CodeRegion"=$o.Reg; "NomRegion"=$o.NomReg; "PaysTexte"="France"; "Latitude"=$o.Lat; "Longitude"=$o.Lon; "Statut"="Actif"} }

$msg = "Ajouts - Regions: $regionsAdded, Departements: $depsAdded, Villes: $villesAdded, CodesPostaux: $cpsAdded, Relations CP/Villes: $relsAdded."
Write-Host $msg -ForegroundColor Green
Add-DSEJournalAction -Action "Import geographie France" -Objet "Geographie" -Resultat "OK" -Message $msg
