﻿param([string]$Root)
. "$PSScriptRoot\_common.ps1"
Connect-DSESharePoint
$lists = @("Pays","Regions","Departements","Villes","CodesPostaux","CodesPostauxVilles")
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " CONTROLE FINAL GEOGRAPHIE FRANCE" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
foreach ($l in $lists) { try { $c=(Get-PnPListItem -List $l -PageSize 5000).Count; Write-Host "$l : $c elements" -ForegroundColor Green } catch { Write-Host "$l : erreur" -ForegroundColor Red } }
Write-Host "============================================================" -ForegroundColor Cyan
Add-DSEJournalAction -Action "Controle final geographie France" -Objet "Geographie" -Resultat "OK" -Message "Controle final execute sur Pays, Regions, Departements, Villes, CodesPostaux, CodesPostauxVilles."
