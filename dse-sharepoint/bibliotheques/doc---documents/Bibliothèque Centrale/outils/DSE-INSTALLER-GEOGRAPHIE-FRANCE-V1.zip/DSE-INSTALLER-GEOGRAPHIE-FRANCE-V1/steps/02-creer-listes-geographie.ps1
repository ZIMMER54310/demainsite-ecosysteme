﻿param([string]$Root)
. "$PSScriptRoot\_common.ps1"
Connect-DSESharePoint

# Pays existe deja possiblement : on le complete.
Ensure-DSEList -Title "Pays"
Ensure-DSEField -ListName "Pays" -DisplayName "ID Pays" -InternalName "IDPays" -Type Text
Ensure-DSEField -ListName "Pays" -DisplayName "Code Pays" -InternalName "CodePays" -Type Text
Ensure-DSEField -ListName "Pays" -DisplayName "ISO2" -InternalName "ISO2" -Type Text
Ensure-DSEField -ListName "Pays" -DisplayName "Statut" -InternalName "Statut" -Type Text

Ensure-DSEList -Title "Regions"
Ensure-DSEField -ListName "Regions" -DisplayName "ID Region" -InternalName "IDRegion" -Type Text
Ensure-DSEField -ListName "Regions" -DisplayName "Code Region" -InternalName "CodeRegion" -Type Text
Ensure-DSEField -ListName "Regions" -DisplayName "Nom Region" -InternalName "NomRegion" -Type Text
Ensure-DSEField -ListName "Regions" -DisplayName "Pays" -InternalName "PaysTexte" -Type Text
Ensure-DSEField -ListName "Regions" -DisplayName "Statut" -InternalName "Statut" -Type Text

Ensure-DSEList -Title "Departements"
Ensure-DSEField -ListName "Departements" -DisplayName "ID Departement" -InternalName "IDDepartement" -Type Text
Ensure-DSEField -ListName "Departements" -DisplayName "Code Departement" -InternalName "CodeDepartement" -Type Text
Ensure-DSEField -ListName "Departements" -DisplayName "Nom Departement" -InternalName "NomDepartement" -Type Text
Ensure-DSEField -ListName "Departements" -DisplayName "Code Region" -InternalName "CodeRegion" -Type Text
Ensure-DSEField -ListName "Departements" -DisplayName "Nom Region" -InternalName "NomRegion" -Type Text
Ensure-DSEField -ListName "Departements" -DisplayName "Pays" -InternalName "PaysTexte" -Type Text
Ensure-DSEField -ListName "Departements" -DisplayName "Statut" -InternalName "Statut" -Type Text

Ensure-DSEList -Title "Villes"
Ensure-DSEField -ListName "Villes" -DisplayName "ID Ville" -InternalName "IDVille" -Type Text
Ensure-DSEField -ListName "Villes" -DisplayName "Code INSEE" -InternalName "CodeINSEE" -Type Text
Ensure-DSEField -ListName "Villes" -DisplayName "Nom Ville" -InternalName "NomVille" -Type Text
Ensure-DSEField -ListName "Villes" -DisplayName "Nom postal" -InternalName "NomPostal" -Type Text
Ensure-DSEField -ListName "Villes" -DisplayName "Code Departement" -InternalName "CodeDepartement" -Type Text
Ensure-DSEField -ListName "Villes" -DisplayName "Nom Departement" -InternalName "NomDepartement" -Type Text
Ensure-DSEField -ListName "Villes" -DisplayName "Code Region" -InternalName "CodeRegion" -Type Text
Ensure-DSEField -ListName "Villes" -DisplayName "Nom Region" -InternalName "NomRegion" -Type Text
Ensure-DSEField -ListName "Villes" -DisplayName "Pays" -InternalName "PaysTexte" -Type Text
Ensure-DSEField -ListName "Villes" -DisplayName "Latitude" -InternalName "Latitude" -Type Number
Ensure-DSEField -ListName "Villes" -DisplayName "Longitude" -InternalName "Longitude" -Type Number
Ensure-DSEField -ListName "Villes" -DisplayName "Statut" -InternalName "Statut" -Type Text

Ensure-DSEList -Title "CodesPostaux"
Ensure-DSEField -ListName "CodesPostaux" -DisplayName "ID Code Postal" -InternalName "IDCodePostal" -Type Text
Ensure-DSEField -ListName "CodesPostaux" -DisplayName "Code Postal" -InternalName "CodePostal" -Type Text
Ensure-DSEField -ListName "CodesPostaux" -DisplayName "Pays" -InternalName "PaysTexte" -Type Text
Ensure-DSEField -ListName "CodesPostaux" -DisplayName "Nombre Villes" -InternalName "NombreVilles" -Type Number
Ensure-DSEField -ListName "CodesPostaux" -DisplayName "Regions associees" -InternalName "RegionsAssociees" -Type Note
Ensure-DSEField -ListName "CodesPostaux" -DisplayName "Departements associes" -InternalName "DepartementsAssocies" -Type Note
Ensure-DSEField -ListName "CodesPostaux" -DisplayName "Statut" -InternalName "Statut" -Type Text

Ensure-DSEList -Title "CodesPostauxVilles"
Ensure-DSEField -ListName "CodesPostauxVilles" -DisplayName "ID CP Ville" -InternalName "IDCPVille" -Type Text
Ensure-DSEField -ListName "CodesPostauxVilles" -DisplayName "Cle CP Ville" -InternalName "CleCPVille" -Type Text
Ensure-DSEField -ListName "CodesPostauxVilles" -DisplayName "Code Postal" -InternalName "CodePostal" -Type Text
Ensure-DSEField -ListName "CodesPostauxVilles" -DisplayName "Code INSEE" -InternalName "CodeINSEE" -Type Text
Ensure-DSEField -ListName "CodesPostauxVilles" -DisplayName "Nom Ville" -InternalName "NomVille" -Type Text
Ensure-DSEField -ListName "CodesPostauxVilles" -DisplayName "Libelle acheminement" -InternalName "LibelleAcheminement" -Type Text
Ensure-DSEField -ListName "CodesPostauxVilles" -DisplayName "Ligne 5" -InternalName "Ligne5" -Type Text
Ensure-DSEField -ListName "CodesPostauxVilles" -DisplayName "Code Departement" -InternalName "CodeDepartement" -Type Text
Ensure-DSEField -ListName "CodesPostauxVilles" -DisplayName "Nom Departement" -InternalName "NomDepartement" -Type Text
Ensure-DSEField -ListName "CodesPostauxVilles" -DisplayName "Code Region" -InternalName "CodeRegion" -Type Text
Ensure-DSEField -ListName "CodesPostauxVilles" -DisplayName "Nom Region" -InternalName "NomRegion" -Type Text
Ensure-DSEField -ListName "CodesPostauxVilles" -DisplayName "Pays" -InternalName "PaysTexte" -Type Text
Ensure-DSEField -ListName "CodesPostauxVilles" -DisplayName "Latitude" -InternalName "Latitude" -Type Number
Ensure-DSEField -ListName "CodesPostauxVilles" -DisplayName "Longitude" -InternalName "Longitude" -Type Number
Ensure-DSEField -ListName "CodesPostauxVilles" -DisplayName "Statut" -InternalName "Statut" -Type Text

Add-DSEJournalAction -Action "Creation listes geographie France" -Objet "Geographie" -Resultat "OK" -Message "Listes Pays, Regions, Departements, Villes, CodesPostaux et CodesPostauxVilles creees ou verifiees."
