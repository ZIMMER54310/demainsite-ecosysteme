﻿DSE-INSTALLER-GEOGRAPHIE-FRANCE-V1

But : creer un referentiel geographique France pour DemainSite Ecosysteme.

Listes creees ou completees :
- Pays
- Regions
- Departements
- Villes
- CodesPostaux
- CodesPostauxVilles

Source :
- data.gouv.fr / Communes de France - Base des codes postaux
- le script telecharge automatiquement le CSV disponible via l'API data.gouv.

Utilisation :
1. Placer ce dossier dans OUTILS / INSTALLATEURS.
2. Double-cliquer RUN-DSE-GEOGRAPHIE.bat.
3. Patienter pendant l'import. C'est plus volumineux que les packs precedents.
4. Verifier les listes : Regions, Departements, Villes, CodesPostaux, CodesPostauxVilles.

Notes :
- Aucune suppression.
- Les relations sont stockees avec codes texte pour rester robustes.
- Les colonnes Lookup pourront etre ajoutees dans une V2 apres validation.
- L'import evite les doublons selon les cles CodeRegion, CodeDepartement, CodeINSEE, CodePostal, CleCPVille.
