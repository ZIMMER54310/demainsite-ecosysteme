# PLAN-DYNAMIQUE-SHAREPOINT-WORDPRESS-VISIO-V1.0

## Objectif
Prévoir dans SharePoint un plan dynamique automatique reliant :

- SharePoint / Bibliothèque Centrale
- Listes métier et référentiels
- WordPress
- Articles
- Produits
- Médias
- Synchronisation et journaux
- Représentation Visio

## Principe validé
SharePoint reste la source de vérité. WordPress utilise les données SharePoint pour publier, afficher, vendre ou relier les contenus.

## Exemple géographie
Pays -> Régions -> Départements -> Villes -> Articles WordPress -> Médias -> Produits.

## À construire après la structure SharePoint
- Liste SharePoint : Plan dynamique DSE
- Vue par domaine : Géographie, Clients, Sites, Médias, Produits, WordPress
- Export ou schéma Visio
- Mise à jour automatique depuis les listes SharePoint
