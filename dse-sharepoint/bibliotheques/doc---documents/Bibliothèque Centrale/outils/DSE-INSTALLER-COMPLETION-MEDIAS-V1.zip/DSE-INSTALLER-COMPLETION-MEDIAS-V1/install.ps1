﻿# ============================================================
# DEMAINSITE ECOSYSTEME - INSTALLATEUR COMPLETION MEDIAS V1
# Complete automatiquement les fiches Medias importees depuis WordPress.
# ============================================================
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$LogDir = Join-Path $Root "logs"
if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Force -Path $LogDir | Out-Null }
$Stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$Log = Join-Path $LogDir "DSE-CompletionMedias-$Stamp.log"
Start-Transcript -Path $Log -Append | Out-Null
try {
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host " DSE - COMPLETION MEDIAS V1" -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    $Steps = @(
        "steps\\01-connexion.ps1",
        "steps\\02-preparer-colonnes.ps1",
        "steps\\03-completer-medias.ps1",
        "steps\\04-vue-medias.ps1",
        "steps\\05-controle-final.ps1"
    )
    foreach ($StepRel in $Steps) {
        $Step = Join-Path $Root $StepRel
        if (-not (Test-Path $Step)) { throw "Fichier manquant : $Step" }
        Write-Host ""; Write-Host "Execution : $StepRel" -ForegroundColor Cyan
        & $Step -Root $Root
        Write-Host "OK : $StepRel" -ForegroundColor Green
    }
    Write-Host ""; Write-Host "INSTALLATION COMPLETION MEDIAS TERMINEE" -ForegroundColor Green
}
catch {
    Write-Host "ERREUR : $($_.Exception.Message)" -ForegroundColor Red
    throw
}
finally { Stop-Transcript | Out-Null }
