﻿DSE-INSTALLER-COMPLETION-MEDIAS-V1

But : completer automatiquement les fiches Medias importees depuis WordPress.

Le pack :
- ajoute Score completude, Derniere completion, Note completion,
- complete ID Media si vide,
- complete Type Media selon MIME/extension,
- complete Categorie Media selon le nom,
- complete Statut, Client Proprietaire, Site Associe, Projet Associe, Licence si possible,
- cree la vue Medias Completes,
- journalise dans JournalActions.

Utilisation :
1. Placer le dossier dans OUTILS / INSTALLATEURS.
2. Double-cliquer RUN-DSE.bat.
3. Verifier SharePoint > Medias > Vue Medias Completes.

Aucune suppression.
Aucune modification WordPress.
