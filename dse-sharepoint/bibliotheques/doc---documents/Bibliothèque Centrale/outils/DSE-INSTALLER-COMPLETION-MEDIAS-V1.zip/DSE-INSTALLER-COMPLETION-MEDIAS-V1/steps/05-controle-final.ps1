﻿param([string]$Root)
. "$PSScriptRoot\_common.ps1"
Connect-DSESharePoint
$items = Get-PnPListItem -List $script:MediaList -PageSize 2000
$total = $items.Count
$scoreField = Get-DSEField -ListName $script:MediaList -Names @("ScoreCompletude","Score completude")
$completeScores = 0
if ($null -ne $scoreField) {
    foreach ($i in $items) { if (-not [string]::IsNullOrWhiteSpace("$($i[$scoreField.InternalName])")) { $completeScores++ } }
}
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " CONTROLE FINAL COMPLETION MEDIAS" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "Medias total          : $total" -ForegroundColor Green
Write-Host "Scores renseignes     : $completeScores" -ForegroundColor Green
Write-Host "Ouvre Medias puis vue Medias Completes." -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Add-DSEJournalAction -Action "Controle final completion medias" -Objet "Medias" -Resultat "OK" -Message "Controle final execute : $total medias, $completeScores scores renseignes."
