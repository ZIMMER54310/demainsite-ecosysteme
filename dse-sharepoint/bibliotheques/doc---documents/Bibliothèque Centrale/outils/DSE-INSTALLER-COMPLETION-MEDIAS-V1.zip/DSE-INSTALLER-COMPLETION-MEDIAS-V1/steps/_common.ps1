﻿$script:SpUrl = "https://blogssite.sharepoint.com/sites/Bibliotheque"
$script:ClientId = "5d607413-77c5-47b2-975a-eaca6827921c"
$script:Tenant = "demainsite.com"
$script:MediaList = "Medias"
$script:SiteSourceDefault = "demainsite.fr"

function Connect-DSESharePoint {
    try {
        $web = Get-PnPWeb -ErrorAction Stop
        Write-Host "Connexion SharePoint active : $($web.Url)" -ForegroundColor Green
    } catch {
        Write-Host "Connexion SharePoint absente. Connexion DeviceLogin..." -ForegroundColor Yellow
        Connect-PnPOnline -Url $script:SpUrl -ClientId $script:ClientId -Tenant $script:Tenant -DeviceLogin
        $web = Get-PnPWeb -ErrorAction Stop
        Write-Host "Connexion SharePoint OK : $($web.Url)" -ForegroundColor Green
    }
}

function Ensure-DSEField {
    param([string]$ListName,[string]$DisplayName,[string]$InternalName,[string]$Type)
    $field = Get-PnPField -List $ListName -Identity $InternalName -ErrorAction SilentlyContinue
    if ($null -eq $field) {
        Add-PnPField -List $ListName -DisplayName $DisplayName -InternalName $InternalName -Type $Type | Out-Null
        Write-Host "Colonne ajoutee : $ListName / $DisplayName" -ForegroundColor Green
    } else {
        Write-Host "Colonne deja presente : $ListName / $DisplayName" -ForegroundColor DarkGreen
    }
}

function Get-DSEField {
    param([string]$ListName,[string[]]$Names)
    $fields = Get-PnPField -List $ListName
    foreach ($n in $Names) {
        $f = $fields | Where-Object { $_.Title -eq $n -or $_.InternalName -eq $n } | Select-Object -First 1
        if ($null -ne $f) { return $f }
    }
    return $null
}

function Get-DSELookupId {
    param([string]$ListName,[string[]]$Titles)
    $list = Get-PnPList -Identity $ListName -ErrorAction SilentlyContinue
    if ($null -eq $list) { return $null }
    $items = Get-PnPListItem -List $ListName -PageSize 2000 -Fields "Title" -ErrorAction SilentlyContinue
    foreach ($title in $Titles) {
        $match = $items | Where-Object { "$($_['Title'])" -eq $title } | Select-Object -First 1
        if ($null -ne $match) { return $match.Id }
    }
    foreach ($title in $Titles) {
        $match = $items | Where-Object { "$($_['Title'])" -like "*$title*" } | Select-Object -First 1
        if ($null -ne $match) { return $match.Id }
    }
    return $null
}

function Get-DSELookupTitle {
    param([string]$ListName,[int]$Id)
    if ($null -eq $Id -or $Id -eq 0) { return "" }
    try {
        $item = Get-PnPListItem -List $ListName -Id $Id -Fields "Title" -ErrorAction Stop
        return "$($item['Title'])"
    } catch { return "" }
}

function Get-DSEResourceIds {
    $ids = @{}
    $ids.TypeImage = Get-DSELookupId -ListName "TypesMedia" -Titles @("Image")
    $ids.TypeVideo = Get-DSELookupId -ListName "TypesMedia" -Titles @("Video","Vidéo")
    $ids.TypeAudio = Get-DSELookupId -ListName "TypesMedia" -Titles @("Audio")
    $ids.TypeDocument = Get-DSELookupId -ListName "TypesMedia" -Titles @("Document")
    $ids.TypeArchive = Get-DSELookupId -ListName "TypesMedia" -Titles @("Archive")
    $ids.TypeFichier = Get-DSELookupId -ListName "TypesMedia" -Titles @("Fichier")
    $ids.CatLogo = Get-DSELookupId -ListName "CategoriesMedia" -Titles @("Logo")
    $ids.CatAvatar = Get-DSELookupId -ListName "CategoriesMedia" -Titles @("Avatar")
    $ids.CatTechnique = Get-DSELookupId -ListName "CategoriesMedia" -Titles @("Technique")
    $ids.CatIllustration = Get-DSELookupId -ListName "CategoriesMedia" -Titles @("Illustration")
    $ids.CatPhoto = Get-DSELookupId -ListName "CategoriesMedia" -Titles @("Photo")
    $ids.CatAClasser = Get-DSELookupId -ListName "CategoriesMedia" -Titles @("A classer","À classer")
    $ids.StatutActif = Get-DSELookupId -ListName "Statuts" -Titles @("Actif")
    $ids.LicAVerifier = Get-DSELookupId -ListName "Licences" -Titles @("A verifier","À vérifier")
    $ids.Site = Get-DSELookupId -ListName "Sites" -Titles @("demainsite.fr","DemainSite","DemainSite Ecosysteme","DemainSite écosystème")
    $ids.Client = Get-DSELookupId -ListName "Clients" -Titles @("DemainSite","Blogs-Site","Pascal")
    $ids.Projet = Get-DSELookupId -ListName "Projets" -Titles @("Bibliotheque Centrale","Bibliothèque Centrale","DemainSite Ecosysteme","DemainSite écosystème")
    return $ids
}

function Set-DSEFieldValue {
    param([hashtable]$Values,[object]$Field,[object]$Value,[string]$TextFallback)
    if ($null -eq $Field) { return }
    $internal = $Field.InternalName
    $type = "$($Field.TypeAsString)"
    if ($type -like "Lookup*") {
        if ($null -ne $Value -and "$Value" -ne "") { $Values[$internal] = $Value }
    } elseif ($type -like "Choice*") {
        if (-not [string]::IsNullOrWhiteSpace($TextFallback)) { $Values[$internal] = $TextFallback }
    } elseif ($type -eq "Number") {
        if ($null -ne $Value -and "$Value" -ne "") { $Values[$internal] = $Value }
    } else {
        if (-not [string]::IsNullOrWhiteSpace($TextFallback)) { $Values[$internal] = $TextFallback }
    }
}

function Add-DSEJournalAction {
    param([string]$Action,[string]$Objet,[string]$Resultat,[string]$Message)
    try {
        $list = Get-PnPList -Identity "JournalActions" -ErrorAction SilentlyContinue
        if ($null -eq $list) { return }
        $items = Get-PnPListItem -List "JournalActions" -PageSize 2000 -Fields "IDJournal" -ErrorAction SilentlyContinue
        $max = 0
        foreach ($item in $items) {
            $v = "$($item['IDJournal'])"
            if ($v -match "^JRN-([0-9]+)$") { $n = [int]$matches[1]; if ($n -gt $max) { $max = $n } }
        }
        $id = ("JRN-{0:D6}" -f ($max + 1))
        Add-PnPListItem -List "JournalActions" -Values @{
            "Title"=$Action; "IDJournal"=$id; "DateAction"=Get-Date; "Source"="PowerShell"; "Objet"=$Objet; "Resultat"=$Resultat; "Message"=$Message; "Utilisateur"=$env:USERNAME
        } | Out-Null
    } catch { Write-Host "Journal non ecrit : $($_.Exception.Message)" -ForegroundColor Yellow }
}
