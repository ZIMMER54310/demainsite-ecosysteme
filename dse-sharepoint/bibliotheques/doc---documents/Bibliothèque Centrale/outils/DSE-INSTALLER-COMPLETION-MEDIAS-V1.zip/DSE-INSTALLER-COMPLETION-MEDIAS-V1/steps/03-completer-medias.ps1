﻿param([string]$Root)
. "$PSScriptRoot\_common.ps1"
Connect-DSESharePoint

$ids = Get-DSEResourceIds
$fields = @{}
$fields.IdMedia = Get-DSEField -ListName $script:MediaList -Names @("ID Media","ID_Media","IDMedia","DS_Media_ID")
$fields.WpId = Get-DSEField -ListName $script:MediaList -Names @("WP_ID","ID WordPress")
$fields.NomFichier = Get-DSEField -ListName $script:MediaList -Names @("Nom_Fichier","Nom fichier")
$fields.Mime = Get-DSEField -ListName $script:MediaList -Names @("Mime_Type","Type MIME")
$fields.Extension = Get-DSEField -ListName $script:MediaList -Names @("Extension")
$fields.TypeMedia = Get-DSEField -ListName $script:MediaList -Names @("Type Media","Type_Media","Ref_TypeMedia")
$fields.CategorieMedia = Get-DSEField -ListName $script:MediaList -Names @("Categorie Media","Catégorie Media","Ref_CategorieMedia")
$fields.Client = Get-DSEField -ListName $script:MediaList -Names @("Client Proprietaire","Client Propriétaire","Client_x0020_Proprietaire")
$fields.Statut = Get-DSEField -ListName $script:MediaList -Names @("Statut","DS_Status","Statut DemainSite","Ref_Statut")
$fields.Projet = Get-DSEField -ListName $script:MediaList -Names @("Projet Associe","Projet Associé","Projet_x0020_Associe")
$fields.Site = Get-DSEField -ListName $script:MediaList -Names @("Site Associe","Site Associé","Site_x0020_Associe")
$fields.Licence = Get-DSEField -ListName $script:MediaList -Names @("Licence","Ref_Licence")
$fields.Source = Get-DSEField -ListName $script:MediaList -Names @("Source")
$fields.NombreUtilisations = Get-DSEField -ListName $script:MediaList -Names @("Nombre Utilisations","Nombre Utilisat...","Nombre_Utilisations","NombreUtilisations")
$fields.Score = Get-DSEField -ListName $script:MediaList -Names @("ScoreCompletude","Score completude")
$fields.DateCompletion = Get-DSEField -ListName $script:MediaList -Names @("DerniereCompletion","Derniere completion")
$fields.NoteCompletion = Get-DSEField -ListName $script:MediaList -Names @("NoteCompletion","Note completion")

$items = Get-PnPListItem -List $script:MediaList -PageSize 2000
$updated = 0
$errors = 0

foreach ($item in $items) {
    try {
        $title = "$($item['Title'])"
        $wpId = ""
        if ($null -ne $fields.WpId) { $wpId = "$($item[$fields.WpId.InternalName])" }
        $mime = ""
        if ($null -ne $fields.Mime) { $mime = "$($item[$fields.Mime.InternalName])" }
        $ext = ""
        if ($null -ne $fields.Extension) { $ext = "$($item[$fields.Extension.InternalName])" }
        $fileName = ""
        if ($null -ne $fields.NomFichier) { $fileName = "$($item[$fields.NomFichier.InternalName])" }
        if ([string]::IsNullOrWhiteSpace($fileName)) { $fileName = $title }

        $typeId = $ids.TypeFichier
        $typeText = "Fichier"
        if ($mime -like "image/*" -or $ext -match "^(jpg|jpeg|png|webp|gif|svg)$") { $typeId = $ids.TypeImage; $typeText = "Image" }
        elseif ($mime -like "video/*" -or $ext -match "^(mp4|mov|avi|webm)$") { $typeId = $ids.TypeVideo; $typeText = "Video" }
        elseif ($mime -like "audio/*" -or $ext -match "^(mp3|wav|ogg)$") { $typeId = $ids.TypeAudio; $typeText = "Audio" }
        elseif ($mime -like "application/pdf" -or $ext -match "^(pdf|doc|docx|xls|xlsx|ppt|pptx)$") { $typeId = $ids.TypeDocument; $typeText = "Document" }
        elseif ($ext -match "^(zip|rar|7z)$") { $typeId = $ids.TypeArchive; $typeText = "Archive" }

        $catId = $ids.CatAClasser
        $catText = "A classer"
        $low = ($title + " " + $fileName).ToLowerInvariant()
        if ($low -like "*logo*") { $catId = $ids.CatLogo; $catText = "Logo" }
        elseif ($low -like "*avatar*") { $catId = $ids.CatAvatar; $catText = "Avatar" }
        elseif ($low -like "*placeholder*") { $catId = $ids.CatTechnique; $catText = "Technique" }
        elseif ($low -like "*canvas*" -or $low -like "*fond*") { $catId = $ids.CatIllustration; $catText = "Illustration" }
        elseif ($typeText -eq "Image") { $catId = $ids.CatPhoto; $catText = "Photo" }

        $values = @{}
        if ($null -ne $fields.IdMedia) {
            $currentId = "$($item[$fields.IdMedia.InternalName])"
            if ([string]::IsNullOrWhiteSpace($currentId)) {
                if (-not [string]::IsNullOrWhiteSpace($wpId)) { $values[$fields.IdMedia.InternalName] = "MED-WP-$wpId" }
                else { $values[$fields.IdMedia.InternalName] = "MED-SP-$($item.Id)" }
            }
        }
        Set-DSEFieldValue -Values $values -Field $fields.TypeMedia -Value $typeId -TextFallback $typeText
        Set-DSEFieldValue -Values $values -Field $fields.CategorieMedia -Value $catId -TextFallback $catText
        Set-DSEFieldValue -Values $values -Field $fields.Statut -Value $ids.StatutActif -TextFallback "Actif"
        Set-DSEFieldValue -Values $values -Field $fields.Client -Value $ids.Client -TextFallback (Get-DSELookupTitle -ListName "Clients" -Id $ids.Client)
        Set-DSEFieldValue -Values $values -Field $fields.Projet -Value $ids.Projet -TextFallback (Get-DSELookupTitle -ListName "Projets" -Id $ids.Projet)
        Set-DSEFieldValue -Values $values -Field $fields.Site -Value $ids.Site -TextFallback (Get-DSELookupTitle -ListName "Sites" -Id $ids.Site)
        Set-DSEFieldValue -Values $values -Field $fields.Licence -Value $ids.LicAVerifier -TextFallback "A verifier"
        if ($null -ne $fields.Source -and [string]::IsNullOrWhiteSpace("$($item[$fields.Source.InternalName])")) { $values[$fields.Source.InternalName] = "WordPress public" }
        if ($null -ne $fields.NombreUtilisations -and [string]::IsNullOrWhiteSpace("$($item[$fields.NombreUtilisations.InternalName])")) { $values[$fields.NombreUtilisations.InternalName] = 0 }

        # Calcul simple du score sur 9 champs clés
        $scoreFields = @("id","title","type","client","statut","projet","site","licence","source")
        $done = 0
        if ($null -ne $fields.IdMedia -and (-not [string]::IsNullOrWhiteSpace("$($item[$fields.IdMedia.InternalName])") -or $values.ContainsKey($fields.IdMedia.InternalName))) { $done++ }
        if (-not [string]::IsNullOrWhiteSpace($title)) { $done++ }
        if ($null -ne $fields.TypeMedia) { $done++ }
        if ($null -ne $fields.Client) { $done++ }
        if ($null -ne $fields.Statut) { $done++ }
        if ($null -ne $fields.Projet) { $done++ }
        if ($null -ne $fields.Site) { $done++ }
        if ($null -ne $fields.Licence) { $done++ }
        if ($null -ne $fields.Source) { $done++ }
        $score = [math]::Round(($done / 9) * 100)
        if ($null -ne $fields.Score) { $values[$fields.Score.InternalName] = $score }
        if ($null -ne $fields.DateCompletion) { $values[$fields.DateCompletion.InternalName] = Get-Date }
        if ($null -ne $fields.NoteCompletion) { $values[$fields.NoteCompletion.InternalName] = "Completion automatique PascARA IA V1 : type, categorie, statut, client, projet, site, licence et score de completude selon les donnees disponibles." }

        if ($values.Count -gt 0) {
            Set-PnPListItem -List $script:MediaList -Identity $item.Id -Values $values | Out-Null
            $updated++
            Write-Host "Media complete : $title / score $score%" -ForegroundColor Green
        }
    } catch {
        $errors++
        Write-Host "Erreur media ID $($item.Id)" -ForegroundColor Red
        Write-Host $_.Exception.Message -ForegroundColor Red
    }
}

Add-DSEJournalAction -Action "Completion automatique medias" -Objet "Medias" -Resultat "OK" -Message "Medias traites : $($items.Count). Mis a jour : $updated. Erreurs : $errors."
Write-Host "Medias mis a jour : $updated / Erreurs : $errors" -ForegroundColor Cyan
