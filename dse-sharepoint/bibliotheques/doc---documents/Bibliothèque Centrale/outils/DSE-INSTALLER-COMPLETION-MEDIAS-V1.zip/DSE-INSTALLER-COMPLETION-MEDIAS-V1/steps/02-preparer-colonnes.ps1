﻿param([string]$Root)
. "$PSScriptRoot\_common.ps1"
Connect-DSESharePoint
Ensure-DSEField -ListName $script:MediaList -DisplayName "Score completude" -InternalName "ScoreCompletude" -Type Number
Ensure-DSEField -ListName $script:MediaList -DisplayName "Derniere completion" -InternalName "DerniereCompletion" -Type DateTime
Ensure-DSEField -ListName $script:MediaList -DisplayName "Note completion" -InternalName "NoteCompletion" -Type Note
Add-DSEJournalAction -Action "Preparation colonnes medias" -Objet "Medias" -Resultat "OK" -Message "Colonnes ScoreCompletude, DerniereCompletion et NoteCompletion verifiees."
