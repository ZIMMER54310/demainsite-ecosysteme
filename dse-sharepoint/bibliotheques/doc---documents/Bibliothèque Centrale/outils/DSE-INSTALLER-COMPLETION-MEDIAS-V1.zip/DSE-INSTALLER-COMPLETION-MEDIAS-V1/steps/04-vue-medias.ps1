﻿param([string]$Root)
. "$PSScriptRoot\_common.ps1"
Connect-DSESharePoint
$viewFields = @("Title","ID_Media","DS_Media_ID","Type_x0020_Media","TypeMedia","Client_x0020_Proprietaire","Statut","Projet_x0020_Associe","Site_x0020_Associe","Licence","ScoreCompletude","Source")
$existing = @()
$fields = Get-PnPField -List $script:MediaList
foreach ($vf in $viewFields) {
    $f = $fields | Where-Object { $_.InternalName -eq $vf } | Select-Object -First 1
    if ($null -ne $f) { $existing += $vf }
}
if ($existing.Count -lt 2) { $existing = @("Title","Source") }
try {
    $view = Get-PnPView -List $script:MediaList -Identity "Medias Completes" -ErrorAction SilentlyContinue
    if ($null -eq $view) {
        Add-PnPView -List $script:MediaList -Title "Medias Completes" -Fields $existing -SetAsDefault | Out-Null
        Write-Host "Vue Medias Completes creee." -ForegroundColor Green
    } else {
        Set-PnPView -List $script:MediaList -Identity "Medias Completes" -Fields $existing -SetAsDefault | Out-Null
        Write-Host "Vue Medias Completes mise a jour." -ForegroundColor Green
    }
} catch { Write-Host "Vue non modifiee : $($_.Exception.Message)" -ForegroundColor Yellow }
Add-DSEJournalAction -Action "Vue Medias Completes" -Objet "Medias" -Resultat "OK" -Message "Vue Medias Completes creee ou mise a jour."
