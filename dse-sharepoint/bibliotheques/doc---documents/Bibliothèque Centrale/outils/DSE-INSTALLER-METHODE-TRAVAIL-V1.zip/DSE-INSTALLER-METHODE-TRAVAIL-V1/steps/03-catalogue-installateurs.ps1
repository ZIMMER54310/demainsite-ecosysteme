﻿param([string]$Root)
. "$PSScriptRoot\_common.ps1"
Connect-DSESharePoint
Ensure-DSEList -Title "CatalogueInstallateurs"
Ensure-DSEField -ListName "CatalogueInstallateurs" -DisplayName "ID Installateur" -InternalName "IDInstallateur" -Type Text
Ensure-DSEField -ListName "CatalogueInstallateurs" -DisplayName "Nom installateur" -InternalName "NomInstallateur" -Type Text
Ensure-DSEField -ListName "CatalogueInstallateurs" -DisplayName "Version" -InternalName "VersionInstallateur" -Type Text
Ensure-DSEField -ListName "CatalogueInstallateurs" -DisplayName "Famille" -InternalName "Famille" -Type Text
Ensure-DSEField -ListName "CatalogueInstallateurs" -DisplayName "Chemin recommande" -InternalName "CheminRecommande" -Type Text
Ensure-DSEField -ListName "CatalogueInstallateurs" -DisplayName "Statut" -InternalName "Statut" -Type Text
Ensure-DSEField -ListName "CatalogueInstallateurs" -DisplayName "Derniere execution" -InternalName "DerniereExecution" -Type DateTime
Ensure-DSEField -ListName "CatalogueInstallateurs" -DisplayName "Note" -InternalName "NoteInstallateur" -Type Note
Add-DSEJournalAction -Action "Mise en place CatalogueInstallateurs" -Objet "CatalogueInstallateurs" -Resultat "OK" -Message "Catalogue des packs installateurs cree ou verifie."
