﻿param([string]$Root)
. "$PSScriptRoot\_common.ps1"
Connect-DSESharePoint
$nom = "DSE-INSTALLER-METHODE-TRAVAIL-V1"
$existing = Get-PnPListItem -List "CatalogueInstallateurs" -PageSize 2000 -Fields "Title","NomInstallateur" -ErrorAction SilentlyContinue | Where-Object { $_["NomInstallateur"] -eq $nom -or $_["Title"] -eq $nom } | Select-Object -First 1
$id = ""
if ($null -ne $existing) { $id = "$($existing['IDInstallateur'])" }
if ([string]::IsNullOrWhiteSpace($id)) { $id = New-DSEId -ListName "CatalogueInstallateurs" -FieldName "IDInstallateur" -Prefix "INS" }
$values = @{
    "Title"=$nom; "IDInstallateur"=$id; "NomInstallateur"=$nom; "VersionInstallateur"="1.0.0"; "Famille"="Methode de travail"; "CheminRecommande"=$Root; "Statut"="Actif"; "DerniereExecution"=Get-Date; "NoteInstallateur"="Installateur de la methode de travail DemainSite : journaux, catalogue installateurs, execution par pack."
}
if ($null -ne $existing) { Set-PnPListItem -List "CatalogueInstallateurs" -Identity $existing.Id -Values $values | Out-Null; Write-Host "Installateur mis a jour : $nom" -ForegroundColor Yellow }
else { Add-PnPListItem -List "CatalogueInstallateurs" -Values $values | Out-Null; Write-Host "Installateur ajoute : $nom" -ForegroundColor Green }
Add-DSEJournalAction -Action "Enregistrement installateur" -Objet $nom -Resultat "OK" -Message "Installateur courant enregistre dans CatalogueInstallateurs."
