﻿param([string]$Root)
. "$PSScriptRoot\_common.ps1"
Connect-DSESharePoint
$ja = (Get-PnPListItem -List "JournalActions" -PageSize 2000).Count
$je = (Get-PnPListItem -List "JournalErreurs" -PageSize 2000).Count
$ci = (Get-PnPListItem -List "CatalogueInstallateurs" -PageSize 2000).Count
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " CONTROLE FINAL METHODE DE TRAVAIL" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "JournalActions        : $ja elements" -ForegroundColor Green
Write-Host "JournalErreurs        : $je elements" -ForegroundColor Green
Write-Host "CatalogueInstallateurs: $ci elements" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Cyan
Add-DSEJournalAction -Action "Controle final methode de travail" -Objet "DSE-INSTALLER-METHODE-TRAVAIL-V1" -Resultat "OK" -Message "Controle final termine."
