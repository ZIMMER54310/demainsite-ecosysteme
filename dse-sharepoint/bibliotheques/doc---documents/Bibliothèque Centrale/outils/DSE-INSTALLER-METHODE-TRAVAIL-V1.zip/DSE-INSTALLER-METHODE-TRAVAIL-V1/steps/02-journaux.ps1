﻿param([string]$Root)
. "$PSScriptRoot\_common.ps1"
Connect-DSESharePoint
Ensure-DSEList -Title "JournalActions"
Ensure-DSEField -ListName "JournalActions" -DisplayName "ID Journal" -InternalName "IDJournal" -Type Text
Ensure-DSEField -ListName "JournalActions" -DisplayName "Date action" -InternalName "DateAction" -Type DateTime
Ensure-DSEField -ListName "JournalActions" -DisplayName "Utilisateur" -InternalName "Utilisateur" -Type Text
Ensure-DSEField -ListName "JournalActions" -DisplayName "Source" -InternalName "Source" -Type Text
Ensure-DSEField -ListName "JournalActions" -DisplayName "Objet" -InternalName "Objet" -Type Text
Ensure-DSEField -ListName "JournalActions" -DisplayName "Resultat" -InternalName "Resultat" -Type Text
Ensure-DSEField -ListName "JournalActions" -DisplayName "Message" -InternalName "Message" -Type Note
Ensure-DSEList -Title "JournalErreurs"
Ensure-DSEField -ListName "JournalErreurs" -DisplayName "ID Erreur" -InternalName "IDErreur" -Type Text
Ensure-DSEField -ListName "JournalErreurs" -DisplayName "Date erreur" -InternalName "DateErreur" -Type DateTime
Ensure-DSEField -ListName "JournalErreurs" -DisplayName "Utilisateur" -InternalName "Utilisateur" -Type Text
Ensure-DSEField -ListName "JournalErreurs" -DisplayName "Source" -InternalName "Source" -Type Text
Ensure-DSEField -ListName "JournalErreurs" -DisplayName "Objet" -InternalName "Objet" -Type Text
Ensure-DSEField -ListName "JournalErreurs" -DisplayName "Statut erreur" -InternalName "StatutErreur" -Type Text
Ensure-DSEField -ListName "JournalErreurs" -DisplayName "Message erreur" -InternalName "MessageErreur" -Type Note
Add-DSEJournalAction -Action "Mise en place journaux" -Objet "JournalActions / JournalErreurs" -Resultat "OK" -Message "Listes de journal creees ou verifiees."
