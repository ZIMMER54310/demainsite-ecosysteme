﻿DSE-INSTALLER-METHODE-TRAVAIL-V1

But : mettre en place la methode officielle DemainSite :
- execution par pack installateur,
- stockage dans SharePoint / OneDrive,
- JournalActions,
- JournalErreurs,
- CatalogueInstallateurs.

Utilisation :
1. Placer ce dossier dans DemainSite ecosysteme - Bibliotheque Centrale / OUTILS / INSTALLATEURS.
2. Double-cliquer RUN-DSE.bat.
3. Verifier dans SharePoint : JournalActions, JournalErreurs, CatalogueInstallateurs.

Aucune suppression.
Aucune modification WordPress.
