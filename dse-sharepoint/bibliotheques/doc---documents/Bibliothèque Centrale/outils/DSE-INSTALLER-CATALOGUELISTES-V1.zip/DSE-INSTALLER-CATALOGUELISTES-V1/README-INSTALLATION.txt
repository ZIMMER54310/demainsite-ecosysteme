﻿DEMAINSITE ECOSYSTEME - INSTALLATEUR CATALOGUELISTES V1

OBJECTIF
- Eviter les gros copier-coller dans PowerShell.
- Installer CatalogueListes proprement avec colonnes, IDs, remplissage automatique, vue admin et journal.

UTILISATION
1. Decompresser ce dossier dans C:\DSE ou sur le Bureau.
2. Clic droit sur RUN-DSE.bat > Executer.
   OU depuis PowerShell :
   pwsh -NoProfile -ExecutionPolicy Bypass -File "C:\DSE\install.ps1"

RESULTAT ATTENDU
- CatalogueListes contient une ligne par liste SharePoint visible.
- Chaque ligne a un ID CAT-000001, CAT-000002, etc.
- La vue Catalogue Admin affiche les colonnes utiles.
- Les journaux sont dans le dossier logs.

NOTES
- Aucune suppression.
- Aucune modification WordPress.
- Connexion SharePoint via DeviceLogin si necessaire.
