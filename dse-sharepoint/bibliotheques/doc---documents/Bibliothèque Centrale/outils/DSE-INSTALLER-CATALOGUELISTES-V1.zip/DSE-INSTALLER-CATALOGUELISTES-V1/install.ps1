﻿# ============================================================
# DEMAINSITE ECOSYSTEME - INSTALLATEUR PRINCIPAL
# CatalogueListes V1
# Ne pas coller dans PowerShell : executer ce fichier .ps1
# ============================================================

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$LogDir = Join-Path $Root "logs"
if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Force -Path $LogDir | Out-Null }
$Stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$Log = Join-Path $LogDir "DSE-CatalogueListes-$Stamp.log"

Start-Transcript -Path $Log -Append | Out-Null

try {
    Write-Host "" 
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host " DEMAINSITE ECOSYSTEME - INSTALLATION CATALOGUELISTES V1" -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host "Dossier : $Root" -ForegroundColor Cyan
    Write-Host "Journal : $Log" -ForegroundColor Cyan

    $Steps = @(
        "steps\\01-connexion.ps1",
        "steps\\02-catalogue-colonnes.ps1",
        "steps\\03-catalogue-remplissage.ps1",
        "steps\\04-catalogue-vue.ps1",
        "steps\\05-controle-final.ps1"
    )

    foreach ($StepRel in $Steps) {
        $Step = Join-Path $Root $StepRel
        if (-not (Test-Path $Step)) { throw "Fichier manquant : $Step" }
        Write-Host "" 
        Write-Host "------------------------------------------------------------" -ForegroundColor Cyan
        Write-Host "Execution : $StepRel" -ForegroundColor Cyan
        Write-Host "------------------------------------------------------------" -ForegroundColor Cyan
        & $Step -Root $Root
        Write-Host "OK : $StepRel" -ForegroundColor Green
    }

    Write-Host "" 
    Write-Host "============================================================" -ForegroundColor Green
    Write-Host " INSTALLATION TERMINEE" -ForegroundColor Green
    Write-Host "============================================================" -ForegroundColor Green
}
catch {
    Write-Host "" 
    Write-Host "ERREUR INSTALLATEUR :" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    throw
}
finally {
    Stop-Transcript | Out-Null
}
