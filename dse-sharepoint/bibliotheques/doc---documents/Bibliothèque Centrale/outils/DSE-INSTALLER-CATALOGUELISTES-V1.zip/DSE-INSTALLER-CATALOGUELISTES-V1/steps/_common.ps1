﻿# ============================================================
# DEMAINSITE ECOSYSTEME - FONCTIONS COMMUNES
# ============================================================

$script:SpUrl = "https://blogssite.sharepoint.com/sites/Bibliotheque"
$script:ClientId = "5d607413-77c5-47b2-975a-eaca6827921c"
$script:Tenant = "demainsite.com"
$script:CatalogueName = "CatalogueListes"

function Connect-DSESharePoint {
    try {
        $web = Get-PnPWeb -ErrorAction Stop
        Write-Host "Connexion SharePoint active : $($web.Url)" -ForegroundColor Green
    }
    catch {
        Write-Host "Connexion SharePoint absente. Connexion DeviceLogin..." -ForegroundColor Yellow
        Connect-PnPOnline -Url $script:SpUrl -ClientId $script:ClientId -Tenant $script:Tenant -DeviceLogin
        $web = Get-PnPWeb -ErrorAction Stop
        Write-Host "Connexion SharePoint OK : $($web.Url)" -ForegroundColor Green
    }
}

function Ensure-DSEList {
    param([string]$Title)
    $list = Get-PnPList -Identity $Title -ErrorAction SilentlyContinue
    if ($null -eq $list) {
        New-PnPList -Title $Title -Template GenericList -OnQuickLaunch | Out-Null
        Write-Host "Liste creee : $Title" -ForegroundColor Green
    } else {
        Write-Host "Liste deja presente : $Title" -ForegroundColor DarkGreen
    }
}

function Ensure-DSEField {
    param(
        [string]$ListName,
        [string]$DisplayName,
        [string]$InternalName,
        [string]$Type
    )
    $field = Get-PnPField -List $ListName -Identity $InternalName -ErrorAction SilentlyContinue
    if ($null -eq $field) {
        Add-PnPField -List $ListName -DisplayName $DisplayName -InternalName $InternalName -Type $Type | Out-Null
        Write-Host "Colonne ajoutee : $DisplayName / $InternalName" -ForegroundColor Green
    } else {
        Write-Host "Colonne deja presente : $DisplayName / $InternalName" -ForegroundColor DarkGreen
    }
}

function Wait-DSEField {
    param([string]$ListName,[string]$InternalName)
    for ($i=1; $i -le 30; $i++) {
        $f = Get-PnPField -List $ListName -Identity $InternalName -ErrorAction SilentlyContinue
        if ($null -ne $f) { return }
        Start-Sleep -Milliseconds 500
    }
    throw "Colonne non disponible apres attente : $InternalName"
}

function Normalize-DSEKey {
    param([string]$Text)
    if ([string]::IsNullOrWhiteSpace($Text)) { return "" }
    $v = $Text.ToLowerInvariant()
    $v = $v -replace "[^a-z0-9]", ""
    return $v
}

function Get-DSEFamille {
    param([string]$Name)
    $metier = @("Relations","Clients","Sites","Domaines","Projets","Pages","Medias","Utilisateurs")
    $referentiel = @("Civilites","Statuts","TypesRelations","TypesSites","TypesDomaines","TypesProjets","TypesMedia","CategoriesMedia","CategoriesPages","Licences","RolesUtilisateurs","Pays","Langues")
    $gouvernance = @("Procedures","CatalogueListes","CatalogueLiensListes","CatalogueIDs")
    if ($metier -contains $Name) { return "Metier" }
    if ($referentiel -contains $Name) { return "Referentiel" }
    if ($gouvernance -contains $Name) { return "Gouvernance" }
    if ($Name -like "*Documents*" -or $Name -like "*Pieces*" -or $Name -like "*styles*" -or $Name -like "*formulaire*" -or $Name -like "*Pages du site*" -or $Name -like "*Bibliotheque*") { return "Systeme SharePoint" }
    return "A classer"
}

function Get-DSERoleListe {
    param([string]$Name)
    switch ($Name) {
        "Relations" { return "Racine metier de l ecosysteme. Rattache clients, sites, projets, domaines, medias et utilisateurs." }
        "Clients" { return "Fiches clients, associations, societes, structures et informations principales." }
        "Sites" { return "Sites WordPress, sites clients, sites actifs et futurs sites de l ecosysteme." }
        "Domaines" { return "Domaines principaux, alias, redirections et rattachements aux sites." }
        "Projets" { return "Projets clients, projets internes, affiches, sites, Microsoft 365, SharePoint et supports." }
        "Pages" { return "Pages WordPress importees ou gerees depuis la Bibliotheque Centrale." }
        "Medias" { return "Images, videos, audios, documents, logos, bannieres et fichiers." }
        "Utilisateurs" { return "Utilisateurs, collaborateurs, clients, responsables et futurs droits." }
        "Procedures" { return "Procedures officielles, gouvernance, reprise, securite et anti-regression." }
        "CatalogueListes" { return "Catalogue central des listes. Sert a retrouver, classer, documenter et eviter les doublons." }
        "Civilites" { return "Referentiel des civilites. Evite les ressaisies de Monsieur, Madame, Societe, Association, etc." }
        "Statuts" { return "Referentiel central des statuts reutilisable par toutes les listes." }
        "TypesRelations" { return "Referentiel des types de relations." }
        "TypesSites" { return "Referentiel des types de sites. Sert aussi aux futurs filtres WordPress." }
        "TypesDomaines" { return "Referentiel des types de domaines." }
        "TypesProjets" { return "Referentiel des types de projets." }
        "TypesMedia" { return "Referentiel des types de medias. Sert aux medias et futurs filtres WordPress." }
        "CategoriesMedia" { return "Referentiel des categories de medias. Sert aux filtres SharePoint et WordPress." }
        "CategoriesPages" { return "Referentiel des categories de pages." }
        "Licences" { return "Referentiel des licences, droits d utilisation et controles avant publication ou vente." }
        "RolesUtilisateurs" { return "Referentiel des roles utilisateurs visibles et futurs droits." }
        "Pays" { return "Referentiel des pays reutilisables." }
        "Langues" { return "Referentiel des langues reutilisables pour sites, pages et WordPress." }
        default { return "Liste detectee automatiquement. A classer ou documenter si necessaire." }
    }
}

function Get-DSEUtiliseePar {
    param([string]$Name)
    switch ($Name) {
        "Relations" { return "Clients, Sites, Domaines, Projets, Medias, Utilisateurs" }
        "Clients" { return "Relations, Sites, Projets, Domaines, Medias, Utilisateurs" }
        "Sites" { return "Clients, Domaines, Pages, Medias, Projets, WordPress" }
        "Domaines" { return "Sites, Clients, Relations" }
        "Projets" { return "Relations, Clients, Sites, Medias, Documents" }
        "Pages" { return "Sites, Medias, CategoriesPages, WordPress" }
        "Medias" { return "Sites, Pages, Projets, TypesMedia, CategoriesMedia, Licences, WordPress" }
        "Utilisateurs" { return "Clients, Relations, Sites, RolesUtilisateurs, WordPress, Teams" }
        "Procedures" { return "Administrateur, PascARA IA, controles, reprises, gouvernance" }
        "CatalogueListes" { return "PascARA IA, cockpit, anti-doublon, recherche globale" }
        "Civilites" { return "Clients, Relations, Utilisateurs, Contacts futurs" }
        "Statuts" { return "Toutes les listes metier et de gouvernance" }
        "TypesRelations" { return "Relations" }
        "TypesSites" { return "Sites, WordPress, filtres cockpit" }
        "TypesDomaines" { return "Domaines" }
        "TypesProjets" { return "Projets" }
        "TypesMedia" { return "Medias, Pages, Produits futurs, WordPress" }
        "CategoriesMedia" { return "Medias, WordPress, filtres publics futurs" }
        "CategoriesPages" { return "Pages, WordPress, navigation future" }
        "Licences" { return "Medias, Produits futurs, Documents, WordPress" }
        "RolesUtilisateurs" { return "Utilisateurs, WordPress, Teams futurs" }
        "Pays" { return "Clients, Utilisateurs, Sites" }
        "Langues" { return "Sites, Pages, Utilisateurs, WordPress" }
        default { return "A analyser" }
    }
}

function Get-DSEVisibleCockpit {
    param([string]$Famille)
    if ($Famille -eq "Metier") { return "Oui" }
    if ($Famille -eq "Referentiel") { return "Parametres" }
    if ($Famille -eq "Gouvernance") { return "Administrateur" }
    return "Non"
}

function Get-DSEVisibleWordPress {
    param([string]$Name)
    $wp = @("Sites","Pages","Medias","TypesSites","TypesMedia","CategoriesMedia","CategoriesPages","Licences","Langues")
    if ($wp -contains $Name) { return "Oui" }
    return "Non"
}
