﻿param([string]$Root)
. "$PSScriptRoot\_common.ps1"
Connect-DSESharePoint

$total = (Get-PnPListItem -List $script:CatalogueName -PageSize 2000).Count
$fields = Get-PnPField -List $script:CatalogueName | Select-Object Title, InternalName
$check = @("IDCatalogue","NomListe","CleNormalisee","Famille","RoleListe","UtiliseePar","VisibleCockpit","VisibleWordPress","ControleDoublon","IDObligatoire","NombreElements","StatutCatalogue")
$missing = @()
foreach ($c in $check) {
    if (-not ($fields | Where-Object { $_.InternalName -eq $c })) { $missing += $c }
}

Write-Host "" 
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " CONTROLE FINAL CATALOGUELISTES" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "Nombre de lignes : $total" -ForegroundColor Green
if ($missing.Count -eq 0) {
    Write-Host "Colonnes obligatoires : OK" -ForegroundColor Green
} else {
    Write-Host "Colonnes manquantes : $($missing -join ', ')" -ForegroundColor Red
}
Write-Host "Ouvre SharePoint : CatalogueListes > Vue Catalogue Admin" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
