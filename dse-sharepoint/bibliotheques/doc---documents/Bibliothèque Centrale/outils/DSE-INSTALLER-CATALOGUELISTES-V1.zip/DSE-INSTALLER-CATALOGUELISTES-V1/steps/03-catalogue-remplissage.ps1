﻿param([string]$Root)
. "$PSScriptRoot\_common.ps1"
Connect-DSESharePoint

$catalogItems = Get-PnPListItem -List $script:CatalogueName -PageSize 2000 -ErrorAction SilentlyContinue
$maxCat = 0
foreach ($item in $catalogItems) {
    $oldId = "$($item['IDCatalogue'])"
    if ($oldId -match "^CAT-([0-9]+)$") {
        $num = [int]$matches[1]
        if ($num -gt $maxCat) { $maxCat = $num }
    }
}

$allLists = Get-PnPList | Where-Object { $_.Hidden -eq $false } | Sort-Object Title
$added = 0
$updated = 0
$duplicates = 0
$errors = 0

foreach ($spList in $allLists) {
    try {
        $name = $spList.Title
        $key = Normalize-DSEKey $name
        $famille = Get-DSEFamille -Name $name
        $role = Get-DSERoleListe -Name $name
        $usedBy = Get-DSEUtiliseePar -Name $name
        $visibleCockpit = Get-DSEVisibleCockpit -Famille $famille
        $visibleWordPress = Get-DSEVisibleWordPress -Name $name
        $count = 0
        try { $count = [int]$spList.ItemCount } catch { $count = 0 }
        $url = ""
        try { $url = $spList.RootFolder.ServerRelativeUrl } catch { $url = "" }

        $existingMatches = Get-PnPListItem -List $script:CatalogueName -PageSize 2000 -Fields "Title","CleNormalisee","IDCatalogue" |
            Where-Object { $_["CleNormalisee"] -eq $key -or $_["Title"] -eq $name } |
            Sort-Object Id

        $mainItem = $existingMatches | Select-Object -First 1
        $catId = ""
        if ($null -ne $mainItem) { $catId = "$($mainItem['IDCatalogue'])" }
        if ([string]::IsNullOrWhiteSpace($catId)) {
            $maxCat++
            $catId = ("CAT-{0:D6}" -f $maxCat)
        }

        $values = @{
            "Title" = $name
            "IDCatalogue" = $catId
            "NomListe" = $name
            "CleNormalisee" = $key
            "Famille" = $famille
            "RoleListe" = $role
            "UtiliseePar" = $usedBy
            "VisibleCockpit" = $visibleCockpit
            "VisibleWordPress" = $visibleWordPress
            "ControleDoublon" = "Oui"
            "CreationDirecteAutorisee" = "Non"
            "IDObligatoire" = "Oui"
            "NombreElements" = $count
            "URLListe" = $url
            "StatutCatalogue" = "Actif"
            "DateScan" = Get-Date
            "NoteCatalogue" = "Catalogue genere automatiquement par PascARA IA. Sert a retrouver la liste, eviter les doublons et preparer les filtres SharePoint et WordPress."
        }

        if ($null -ne $mainItem) {
            Set-PnPListItem -List $script:CatalogueName -Identity $mainItem.Id -Values $values | Out-Null
            $updated++
            Write-Host "Mis a jour : $catId / $name" -ForegroundColor Yellow
            $extraMatches = $existingMatches | Select-Object -Skip 1
            foreach ($dup in $extraMatches) {
                Set-PnPListItem -List $script:CatalogueName -Identity $dup.Id -Values @{
                    "StatutCatalogue" = "Doublon possible"
                    "ControleDoublon" = "A verifier"
                    "NoteCatalogue" = "Doublon possible detecte automatiquement. Ne pas supprimer sans validation Pascal."
                } | Out-Null
                $duplicates++
            }
        } else {
            Add-PnPListItem -List $script:CatalogueName -Values $values | Out-Null
            $added++
            Write-Host "Ajoute : $catId / $name" -ForegroundColor Green
        }
    }
    catch {
        $errors++
        Write-Host "Erreur catalogue sur : $($spList.Title)" -ForegroundColor Red
        Write-Host $_.Exception.Message -ForegroundColor Red
    }
}

$summary = @{
    added=$added
    updated=$updated
    duplicates=$duplicates
    errors=$errors
    date=(Get-Date).ToString("s")
}
$summary | ConvertTo-Json | Set-Content -Path (Join-Path $Root "logs\summary-catalogue-remplissage.json") -Encoding UTF8
Write-Host "Ajoutes : $added / Mis a jour : $updated / Doublons marques : $duplicates / Erreurs : $errors" -ForegroundColor Cyan
