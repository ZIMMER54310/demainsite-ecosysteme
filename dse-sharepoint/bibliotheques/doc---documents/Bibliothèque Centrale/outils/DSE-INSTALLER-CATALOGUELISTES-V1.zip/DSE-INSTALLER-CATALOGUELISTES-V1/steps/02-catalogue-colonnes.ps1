﻿param([string]$Root)
. "$PSScriptRoot\_common.ps1"
Connect-DSESharePoint

Ensure-DSEList -Title $script:CatalogueName

$fields = @(
    @{D="ID Catalogue"; I="IDCatalogue"; T="Text"},
    @{D="Nom liste"; I="NomListe"; T="Text"},
    @{D="Cle normalisee"; I="CleNormalisee"; T="Text"},
    @{D="Famille"; I="Famille"; T="Text"},
    @{D="Role liste"; I="RoleListe"; T="Note"},
    @{D="Utilisee par"; I="UtiliseePar"; T="Note"},
    @{D="Visible cockpit"; I="VisibleCockpit"; T="Text"},
    @{D="Visible WordPress"; I="VisibleWordPress"; T="Text"},
    @{D="Controle doublon"; I="ControleDoublon"; T="Text"},
    @{D="Creation directe autorisee"; I="CreationDirecteAutorisee"; T="Text"},
    @{D="ID obligatoire"; I="IDObligatoire"; T="Text"},
    @{D="Nombre elements"; I="NombreElements"; T="Number"},
    @{D="URL liste"; I="URLListe"; T="Text"},
    @{D="Statut catalogue"; I="StatutCatalogue"; T="Text"},
    @{D="Date scan"; I="DateScan"; T="DateTime"},
    @{D="Note catalogue"; I="NoteCatalogue"; T="Note"}
)

foreach ($f in $fields) {
    Ensure-DSEField -ListName $script:CatalogueName -DisplayName $f.D -InternalName $f.I -Type $f.T
}

Write-Host "Synchronisation schema SharePoint..." -ForegroundColor Cyan
foreach ($f in $fields) {
    Wait-DSEField -ListName $script:CatalogueName -InternalName $f.I
}
Write-Host "Colonnes CatalogueListes disponibles." -ForegroundColor Green
