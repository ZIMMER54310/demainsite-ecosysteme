﻿param([string]$Root)
. "$PSScriptRoot\_common.ps1"
Connect-DSESharePoint

$viewFields = @("Title","IDCatalogue","Famille","VisibleCockpit","VisibleWordPress","NombreElements","ControleDoublon","IDObligatoire","StatutCatalogue","DateScan")
try {
    $existingView = Get-PnPView -List $script:CatalogueName -Identity "Catalogue Admin" -ErrorAction SilentlyContinue
    if ($null -eq $existingView) {
        Add-PnPView -List $script:CatalogueName -Title "Catalogue Admin" -Fields $viewFields -SetAsDefault | Out-Null
        Write-Host "Vue Catalogue Admin creee." -ForegroundColor Green
    } else {
        Set-PnPView -List $script:CatalogueName -Identity "Catalogue Admin" -Fields $viewFields -SetAsDefault | Out-Null
        Write-Host "Vue Catalogue Admin mise a jour." -ForegroundColor Green
    }
}
catch {
    Write-Host "Vue non modifiee automatiquement. Les donnees sont creees." -ForegroundColor Yellow
    Write-Host $_.Exception.Message -ForegroundColor Yellow
}
